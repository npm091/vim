package application;

import com.sudoku.models.Logger;

import javafx.application.Application;
import javafx.stage.Stage;
import model.BoardFx;

/**
 * Sudoku Main Class
 * 
 * @author npm091
 * @since 2022/Mar/06th
 * @version 1.0 - 2022/Mar/12th
 * @version 2.0 - 2023/Mar/30th JavaFX GUI version
 *
 */
public class App extends Application {
  //------------------------------------------------------------------------------
  //- Constants and Variables
  //------------------------------------------------------------------------------
  /** Logger Class Instance */
  private static Logger log = Logger.getLogger();

  /**
   * main method to start
   * 
   * @param args
   */
  public static void main(String[] args) {
    launch(args);
  }

  @Override
  public void start(Stage primaryStage) {
    GameMode.setMode(GameMode.BEFORE_START);
    log.print("started - %s", GameMode.getModeString());
    new BoardFx(primaryStage);
  }
}
