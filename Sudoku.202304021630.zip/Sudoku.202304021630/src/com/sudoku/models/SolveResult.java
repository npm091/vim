package com.sudoku.models;

/**
 * @author npm091
 *
 * Solver result
 *
 */
public enum SolveResult {
  /** Completed filling */
  COMPLETED,

  /** Not complete filling yet */
  IN_PROGRESS,

  /** Failed filling due to wrong choice */
  FAILED,

  /** Error because of contradiction */
  ERROR,

  /** Others? Unable to imagine but */
  OTHERS,
}
