package application;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;
import misc.Constant;

/**
 * Description
 *   Define Game mode behavior such as play, create, study and etc. 
 *   
 * @author npm091
 *
 */
public class GameMode extends Constant {
  /** singleton instance */
  private static GameMode singleton = new GameMode();

  // Game Mode
  private static Map<Integer, String> modeString = new HashMap<Integer, String>() {
    private static final long serialVersionUID = 1L;

    {
      put(BEFORE_START, "BEFORE_START");
      put(GAME_MODE, "GAME_MODE");
      put(CREATION_MODE, "CREATION_MODE");
    }
  };

  /** Log level */
  @Getter
  @Setter
  public static Integer mode = BEFORE_START;

  /**
   * constructor - because singleton nothing to do
   */
  private GameMode() {
  }

  /**
   * Get instance
   *
   * @return
   */
  public static GameMode getGameMode() {
    return singleton;
  }

  /**
   * Get instance
   *
   * @return
   */
  public static String getModeString() {
    return modeString.get(mode);
  }

  /**
   * Get instance
   *
   * @return
   */
  public static Integer setGameMode(Integer plevel) {
    mode = plevel;
    return mode;
  }
}
