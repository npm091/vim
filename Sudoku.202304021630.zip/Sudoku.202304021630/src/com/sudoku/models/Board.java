package com.sudoku.models;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

/**
 * Board class - Sudoku board
 *
 * @author npm091
 * 
 * @version 1.0 - 2021/Jan/3rd  - initial
 * @version 1.1 - 2022/Mar/12th - append analyzer
 *
 */
public class Board extends Constants {
  /** Logger instance */
  private static Logger log = Logger.getLogger();

  /** Sudoku Main Board */
  @Getter
  @Setter
  private Cell cells[][] = new Cell[9][9];

  /** Sudoku game level */
  @Getter
  private int level = 0;

  /**
   * Constructor
   */
  public Board() {
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Point p = new Point(x, y);
        cells[y][x] = new Cell(p, 0);
      }
    }
  }

  /**
   * Copy constructor
   *
   * @param pboard - initialize with parameter board
   */
  public Board(Board pboard) {
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Point p = new Point(x, y);
        this.cells[y][x] = new Cell(p, pboard.cells[y][x].getVal(), pboard.cells[y][x].getCand());
      }
    }
  }

  /**
   * Initialize board with parameter values
   *
   * @param pboard - initialize with parameter board
   */
  public void init(Board pboard) {
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Point p = new Point(x, y);
        this.cells[y][x] = new Cell(p, pboard.cells[y][x].getVal(), 0);
      }
    }
  }

  /**
   * Place a val to the cell
   *
   * @param x   - Cell coordinate x
   * @param y   - Cell coordinate y
   * @param val - Cell value
   * @return if the val could be placed to the cell
   */
  public boolean placeVal(Point p, int val) {
    if (cells[p.y][p.x].getVal() == 0 && cells[p.y][p.x].canPlace(val)) {
      cells[p.y][p.x].setVal(val);
      return true;
    }
    return false;
  }

  /**
   * Place values to the cells
   *
   * @param ps - Point list where can be placed value
   * @return Point list where could place values
   */
  public List<Point> placeVals(List<Point> ps)

  {
    List<Point> ret = new ArrayList<Point>();
    for (Point p : ps) {
      if (cells[p.y][p.x].getVal() == 0 && Utility.countBits(cells[p.y][p.x].getCand()) == 1) {
        cells[p.y][p.x].setVal(Utility.getNtz(cells[p.y][p.x].getCand()));
      } else {
        ret.add(p);
      }
    }
    return ret;
  }

  /**
   * delete value of the cell
   *
   * @param p - Cell point
   * @return Result if the val could be placed to the cell
   */
  public boolean delete(Point p) {
    Cell cell = this.getCells()[p.y][p.x];

    if (!cell.delete()) {
      cell.setStatus(CellStatus.REQUIRED);
      return false;
    }
    reEvaluateCandaites();
    return true;
  }

  /**
   * Re evaluate candidate for all empty cells in board
   */
  private void reEvaluateCandaites() {
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Cell cell = this.getCells()[y][x];
        if (cell.getVal() == 0) {
          cell.setCand(Constants.ALL_CAND_BITS);
        }
      }
    }
    sieveCells(false, SolverMode.FAST_MODE);
  }

  /**
   * Sieve candidates for empty cells
   *
   * @param placeFlag  - if just check or actually placing cells
   * @param solverMode - FAST_MODE, FIND_MODE, or JUDGE_LEVEL
   * @return
   */
  public List<Point> sieveCells(boolean placeFlag, SolverMode solverMode) {
    // SolverMode.FAST_MODE : sieveLoop is set to 1
    // SolverMode.FIND_MODE : sieveLoop is set to 4
    // SolverMode.JUDGE_LEVEL : sieveLoop is set to 100
    int sieveLoop = 1;

    if (solverMode == SolverMode.FIND_MODE) {
      sieveLoop = 4;
    } else if (solverMode == SolverMode.JUDGE_LEVEL) {
      sieveLoop = 100;
    }

    List<Point> points = null;
    for (int i = 0; i < sieveLoop; i++) {
      points = new ArrayList<Point>();
      boolean chgflag = false;

      // 1. Standard rule screening
      // log.info(" 1. Standard rule screening\n");
      int eCount = 0;
      for (int y = 0; y < 9; y++) {
        for (int x = 0; x < 9; x++) {
          if (cells[y][x].getVal() == 0) {
            eCount += sieveCellCand(new Point(x, y));
          }
        }
      }
      if (eCount > 0) {
        chgflag = true;
        level = (level < 2) ? 1 : level;
        // log.info(" -> 1. screened candidates(Level%d)\n", level);
      }

      // 2. Find a single candidate
      // log.info(" 2. Find a single candidate\n");
      eCount = findSingleCand(i);
      if (eCount > 0) {
        chgflag = true;
        level = (level < 3) ? 2 : level;
        // log.info(" -> 2. screened candidates(Level%d)\n", level);
      }

      if (i >= 2) {
        // 3. Find two cells which have same two candidates
        // log.info(" 3. Find two cells which have same two candidates\n");
        eCount = findPairCand(2);
        if (eCount > 0) {
          chgflag = true;
          level = (level < 4) ? 3 : level;
          // log.info(" -> 3-2. screened candidates(Level%d)\n", level);
        }
        eCount = findPairCand(3);
        if (eCount > 0) {
          chgflag = true;
          level = (level < 4) ? 3 : level;
          // log.info(" -> 3-3. screened candidates(Level%d)\n", level);
        }

        eCount = findPairCand(4);
        if (eCount > 0) {
          chgflag = true;
          level = (level < 5) ? 4 : level;
          // log.info(" -> 3-4. screened candidates(Level%d)\n", level);
        }

        if (solverMode == SolverMode.COMPLETE_LEVEL) {
          // 4. Eliminate candidates by other candidates relation
          // log.info(" 4. Eliminate candidates by other candidates relation\n");
          eCount = aiSieveCells();
          if (eCount > 0) {
            chgflag = true;
            level = (level < 5) ? 4 : level;
            // log.info(" -> 4. screened candidates(Level%d)\n", level);
          }

        }
      }

      // Compile sorted candidates list to return
      for (int y = 0; y < 9; y++) {
        for (int x = 0; x < 9; x++) {
          if (cells[y][x].getVal() == 0) {
            Point p = new Point(x, y);
            int count = Utility.countBits(cells[y][x].getCand());
            p.setCand(cells[y][x].getCand());
            p.setCandCount(count);
            points.add(p);
          }
        }
      }

      if (placeFlag) {
        points = placeVals(points);
      }
      if (chgflag) {
        // log.info("Board.sieveCells():cmpBoard\n%s%s",
        // org.toStringAll(), this.toStringAll());
        continue;
      }
      // log.info("Board.sieveCells():break\n%s", this.toStringAll());
      log.info("Board.sieveCells(): loop counter=%d\n", i);
      break;
    }
    Collections.sort(points);
    return points;
  }

  /**
   * Get Cell Placed List
   * @return
   */
  public List<Cell> getPlacedList() {
    List<Cell> cellList = new ArrayList<Cell>();
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Cell cell = cells[y][x];
        if (cell.getVal() != 0 && cell.getCand() != ALL_CAND_BITS) {
          cellList.add(cell);
        }
      }
    }
    return cellList;
  }

  /**
   * Find pair candidate in each line, row and box
   *
   * @param nPair - Number of pair
   * @return Found number
   */
  public int findPairCand(int nPair) {
    int findCount = 0;

    // (1) Points of line directions
    for (int n = 0; n < 9; n++) {
      Map<Integer, Integer> pairBitMap = new HashMap<Integer, Integer>();
      // Search the cells which have same candidates
      for (Point p : Utility.linePointArry(n)) {
        int cand = cells[p.y][p.x].getCand();
        if (cells[p.y][p.x].getVal() == 0 && Utility.countBits(cand) > 0 && Utility.countBits(cand) <= nPair) {
          int count = 0;
          if (pairBitMap.containsKey(cand)) {
            count = pairBitMap.get(cand);
            count++;
          }
          pairBitMap.put(cand, count);
        }
      }

      // Compile pairBitMap
      pairBitMap = compilePairBitMap(pairBitMap, nPair);

      // Delete candidates from the cells that don't have pair candidates
      for (Integer cand : pairBitMap.keySet()) {
        if ((nPair - 1) == pairBitMap.get(cand)) {
          for (Point p : Utility.linePointArry(n)) {
            if (cells[p.y][p.x].getVal() == 0) {
              int tcand = cells[p.y][p.x].getCand();
              if ((tcand & cand) != tcand) {
                // Delete pair candidates from other cells
                int b = (Constants.ALL_CAND_BITS ^ cand) & Constants.ALL_CAND_BITS;
                if (cells[p.y][p.x].getCand() != (tcand & b)) {
                  cells[p.y][p.x].setCand(tcand & b);
                  findCount++;
                }
              }
            }
          }
        }
      }
    }

    // (2) Points of row directions
    for (int n = 0; n < 9; n++) {
      Map<Integer, Integer> pairBitMap = new HashMap<Integer, Integer>();
      // Search the cells which have same candidates
      for (Point p : Utility.rowPointArry(n)) {
        int cand = cells[p.y][p.x].getCand();
        if (cells[p.y][p.x].getVal() == 0 && Utility.countBits(cand) > 0 && Utility.countBits(cand) <= nPair) {
          int count = 0;
          if (pairBitMap.containsKey(cand)) {
            count = pairBitMap.get(cand);
            count++;
          }
          pairBitMap.put(cand, count);
        }
      }

      // Compile pairBitMap
      pairBitMap = compilePairBitMap(pairBitMap, nPair);

      // Delete candidates from the cells that don't have pair candidates
      for (Integer cand : pairBitMap.keySet()) {
        if ((nPair - 1) == pairBitMap.get(cand)) {
          for (Point p : Utility.rowPointArry(n)) {
            if (cells[p.y][p.x].getVal() == 0) {
              int tcand = cells[p.y][p.x].getCand();
              if ((tcand & cand) != tcand) {
                // Delete pair candidates from other cells
                int b = (Constants.ALL_CAND_BITS ^ cand) & Constants.ALL_CAND_BITS;
                if (cells[p.y][p.x].getCand() != (tcand & b)) {
                  cells[p.y][p.x].setCand(tcand & b);
                  findCount++;
                }
              }
            }
          }
        }
      }
    }

    // (3) Points of boxes
    for (int n = 0; n < 9; n++) {
      Map<Integer, Integer> pairBitMap = new HashMap<Integer, Integer>();
      // Search the cells which have same candidates
      for (Point p : Utility.boxPointArry(n)) {
        int cand = cells[p.y][p.x].getCand();
        if (cells[p.y][p.x].getVal() == 0 && Utility.countBits(cand) > 0 && Utility.countBits(cand) <= nPair) {
          int count = 0;
          if (pairBitMap.containsKey(cand)) {
            count = pairBitMap.get(cand);
            count++;
          }
          pairBitMap.put(cand, count);
        }
      }

      // Compile pairBitMap
      pairBitMap = compilePairBitMap(pairBitMap, nPair);

      // Delete candidates from the cells that don't have pair candidates
      for (Integer cand : pairBitMap.keySet()) {
        if ((nPair - 1) == pairBitMap.get(cand)) {
          for (Point p : Utility.boxPointArry(n)) {
            if (cells[p.y][p.x].getVal() == 0) {
              int tcand = cells[p.y][p.x].getCand();
              if ((tcand & cand) != tcand) {
                // Delete pair candidates from other cells
                int b = (Constants.ALL_CAND_BITS ^ cand) & Constants.ALL_CAND_BITS;
                if (cells[p.y][p.x].getCand() != (tcand & b)) {
                  cells[p.y][p.x].setCand(tcand & b);
                  findCount++;
                }
              }
            }
          }
        }
      }
    }

    return findCount;
  }

  /**
   * Compile pairBitMap which have less than counts of candaidates See the
   * following example for detail. Candidate1=189,Candidate2=18,Candidate2=19 ->
   * Candidates=189
   *
   * @param pairBitMap
   * @param nPair
   * @return
   */
  private Map<Integer, Integer> compilePairBitMap(Map<Integer, Integer> pairBitMap, int nPair) {
    // Compiled PairBitMap
    Map<Integer, Integer> tpairBitMap = new HashMap<Integer, Integer>();

    // Pickup nPaired candidates at first
    for (Integer cand : pairBitMap.keySet()) {
      if (nPair == Utility.countBits(cand)) {
        int count = 0;
        if (pairBitMap.containsKey(cand)) {
          count = pairBitMap.get(cand);
          tpairBitMap.put(cand, count);
        }
      }
    }

    // Return 0 if there is no nPaired candidates
    if (tpairBitMap.size() == 0) {
      return tpairBitMap;
    }

    // Compile to maps which have nPaired candidates
    for (Integer cand : pairBitMap.keySet()) {
      if (nPair > Utility.countBits(cand)) {
        for (Integer candp : tpairBitMap.keySet()) {
          if (Utility.countBits(cand) == Utility.countBits(candp & cand)) {
            int count = tpairBitMap.get(candp);
            tpairBitMap.put(candp, ++count);
          }
        }
      }
    }

    return tpairBitMap;
  }

  /**
   * Find single candidate in each line, row and box
   *
   * @param p - Cell point
   * @return Candidates for the cell
   */
  private int findSingleCand(int no) {
    /** Find counter */
    int fCount = 0;

    // Points of line directions
    for (int n = 0; n < 9; n++) {
      getSingleBit(0);
      int singleRes = 0;
      // for (int i = 0; i < 9; i++) {
      // Point p = Utility.linePoint(n, i);
      for (Point p : Utility.linePointArry(n)) {
        if (cells[p.y][p.x].getVal() == 0) {
          singleRes = getSingleBit(cells[p.y][p.x].getCand());
        }
      }
      if (singleRes != 0) {
        // for (int i = 0; i < 9; i++) {
        // Point p = Utility.linePoint(n, i);
        for (Point p : Utility.linePointArry(n)) {
          if ((cells[p.y][p.x].getVal() == 0) && ((cells[p.y][p.x].getCand() & singleRes) != 0)) {
            fCount++;
            // log.debug("Board.findSingleCand()-L%d: %d\n",
            // n, Utility.getNtz(singleRes));
            setSingleBit(p.x, p.y, singleRes);
          }

        }
      }
    }

    // Points of row directions
    for (int n = 0; n < 9; n++) {
      getSingleBit(0);
      int singleRes = 0;
      // for (int i = 0; i < 9; i++) {
      // Point p = Utility.rowPoint(n, i);
      for (Point p : Utility.rowPointArry(n)) {
        if (cells[p.y][p.x].getVal() == 0) {
          singleRes = getSingleBit(cells[p.y][p.x].getCand());
        }
      }
      if (singleRes != 0) {
        // for (int i = 0; i < 9; i++) {
        // Point p = Utility.rowPoint(n, i);
        for (Point p : Utility.rowPointArry(n)) {
          if ((cells[p.y][p.x].getVal() == 0) && ((cells[p.y][p.x].getCand() & singleRes) != 0)) {
            fCount++;
            // log.debug("Board.findSingleCand()-R%d: %d\n",
            // n, Utility.getNtz(singleRes));
            setSingleBit(p.x, p.y, singleRes);
          }

        }
      }
    }

    // Points of boxes
    for (int n = 0; n < 9; n++) {
      getSingleBit(0);
      int singleRes = 0;
      // for (int i = 0; i < 9; i++) {
      // Point p = Utility.boxPoint(n, i);
      for (Point p : Utility.boxPointArry(n)) {
        if (cells[p.y][p.x].getVal() == 0) {
          singleRes = getSingleBit(cells[p.y][p.x].getCand());
        }
      }
      if (singleRes != 0) {
        // for (int i = 0; i < 9; i++) {
        // Point p = Utility.boxPoint(n, i);
        for (Point p : Utility.boxPointArry(n)) {
          if ((cells[p.y][p.x].getVal() == 0) && ((cells[p.y][p.x].getCand() & singleRes) != 0)) {
            fCount++;
            // log.debug("Board.findSingleCand()-B%d: %d\n",
            // n, Utility.getNtz(singleRes));
            setSingleBit(p.x, p.y, singleRes);
          }

        }
      }
    }

    return fCount;
  }

  /**
   * Set single candidate bits to the cell
   *
   * @param cell
   * @param singleBits
   */
  private Cell setSingleBit(int x, int y, int singleBits) {
    int b = 1;
    int cand = cells[y][x].getCand();
    for (int i = 0; i < 9; i++) {
      if (((singleBits & b) != 0) && ((cand & b) != 0)) {
        cells[y][x].setCand(b);
      }
      b = b << 1;
    }
    return cells[y][x];
  }

  /**
   * @brief Get single bit
   *
   * @param[in] t The number to test
   */
  /** result bit */
  private static int r = 0;
  private static int f = Constants.ALL_CAND_BITS;

  private int getSingleBit(int t) {
    /** first bit */
    if (t == 0) {
      r = 0;
      f = Constants.ALL_CAND_BITS;
      return r;
    }

    int b = 1;
    for (int i = 0; i < 9; i++) {
      if ((f & b) != 0) {
        if ((t & b) != 0) {
          r = r | b;
          f = f ^ b;
        }
      } else if ((t & b) != 0) {
        r = r & (~b);
      }
      b = b << 1;
    }
    return r;
  }

  /**
   * Sieve candidates for an empty cell
   *
   * @param p - Cell point
   * @return Clear count
   */
  private int sieveCellCand(Point p) {
    int clrCount = 0;
    int x = p.x;
    int y = p.y;
    int box = (y / 3) * 3 + x / 3;
    for (int i = 0; i < 9; i++) {
      // Sieve candidates for a line direction
      if (cells[y][i].getVal() != 0) {
        clrCount += cells[y][x].clrCand(cells[y][i].getVal()) ? 1 : 0;
      }
      // Sieve candidates for a row direction
      if (cells[i][x].getVal() != 0) {
        clrCount += cells[y][x].clrCand(cells[i][x].getVal()) ? 1 : 0;
      }

      // Sieve candidates for a box
      Point b = Utility.boxPoint(box, i);
      if (cells[b.y][b.x].getVal() != 0) {
        clrCount += cells[y][x].clrCand(cells[b.y][b.x].getVal()) ? 1 : 0;
        ;
      }
    }
    return clrCount;
  }

  /**
   * AI sieve candidates for the empty cells
   */
  private int aiSieveCells() {
    int findCount = 0;
    findCount = aiSieveCells(true);
    findCount += aiSieveCells(false);
    return findCount;
  }

  /**
   * AI sieve candidates for the empty cells
   */
  private int aiSieveCells(boolean rflag) {
    int findCount = 0;

    for (int i = 0; i < 9; i++) {
      for (int j = 0; j < 3; j++) {
        int s = 0;
        for (int k = 0; k < 3; k++) {
          Point p1 = Utility.pickPosBox1(rflag, i, k, j);
          log.debug("Board.aiSieveCells(): (%d,%d,%d)->(%d,%d)\n", i, j, k, p1.x, p1.y);
          int xy = (rflag == true) ? p1.y : p1.x;
          int val = chkbd(rflag, xy, cells[p1.y][p1.x].getCand());
          if (val != 0) {
            s |= val;
            // log.debug("Board.aiSieveCells(): (%d,%d,%d)->(%d,%d)",
            // i, j, k, p1.x, p1.y);
            // log.debug(" val=%03X, s=%02X\n", val, s);
          }
        }
        int d = 0;
        for (int k = 0; k < 6; k++) {
          Point p2 = Utility.pickPosBox2(rflag, i, k, j);
          d |= cells[p2.y][p2.x].getCand();
        }
        int mask = 0;
        for (int k = 0; k < 9; k++) {
          int b = (1 << k) & s;
          if (b != 0 && ((d != 0) && (d & b) == 0)) {
            mask |= (1 << k);
          }
        }
        if (mask != 0) {
          for (int k = 0; k < 6; k++) {
            Point p3 = Utility.pickPosBox3(rflag, i, k, j);
            if (cells[p3.y][p3.x].getVal() == 0) {
              int rbit = cells[p3.y][p3.x].getCand() & mask;
              if (rbit != 0) {
                int cCand = cells[p3.y][p3.x].getCand();
                int wCand = cells[p3.y][p3.x].getCand() ^ rbit;
                if (cCand != wCand) {
                  cells[p3.y][p3.x].setCand(cells[p3.y][p3.x].getCand() ^ rbit);
                  findCount++;
                }
              }
            }
          }
        }
      }
    }
    return findCount;
  }

  /**
   * Check the board
   *
   * @param rflag
   * @param yp
   * @param v
   * @return
   */
  private int chkbd(boolean rflag, int yp, int v) {
    for (int i = 0; i < 9; i++) {
      int bdv = (rflag) ? cells[yp][i].getBitVal() : cells[i][yp].getBitVal();
      if (((1 << (bdv - 1)) & v) != 0) {
        v = v - (1 << (bdv - 1));
      }
    }
    return v;
  }

  /**
   * Set the values in the board box
   *
   * @param boxNo
   * @param values list
   */
  public void setCellsValBlock(int box, int vals[]) {
//        for (int i = 0; i < 9; i++) {
//            Point p = Utility.boxPoint(box, i);
    int i = 0;
    for (Point p : Utility.boxPointArry(box)) {
      cells[p.y][p.x].setVal(vals[i++]);
    }
  }

  /**
   * Set the values in the board box
   *
   * @param boxNo
   * @param values list
   */
  public void setCellsValLine(int ln, int vals[]) {
    for (int i = 0; i < 9; i++) {
      Point p = Utility.linePoint(ln, i);
      cells[p.y][p.x].setVal(vals[i]);
    }
  }

  /**
   * Count empty cells
   *
   * @return empty cells
   */
  public int emptyCount() {
    int empties = 0;

    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        if (cells[y][x].getVal() == 0) {
          empties = empties + 1;
        }
      }
    }
    return empties;
  }

  /**
   * toString - to display candidate board
   *
   * @return Candidate board print string
   */
  public String toStringCand() {
    return toStringCand(this.cells);
  }

  /**
   * toString - to display candidate board
   *
   * @param cs Cell[][]
   * @return Candidate Board print string
   */
  private String toStringCand(Cell[][] cs) {
    return Utility.stringCellCands(cells);
  }

  /**
   * toString - to display board
   *
   * @return Board print string
   */
  public String toString() {
    return toString(this.cells);
  }

  /**
   * toString - to display board
   *
   * @param cs Cell[][]
   * @return Board print string
   */
  public String toString(Cell[][] cs) {
    return Utility.stringCellVals(cells);
  }

  /**
   * toString - to display board
   *
   * @return Board print string
   */
  public String toStringAll() {
    return toStringAll(this.cells);
  }

  /**
   * toString - to display board
   *
   * @param cs Cell[][]
   * @return Board print string
   */
  public String toStringAll(Cell[][] cs) {
    return Utility.stringCellｓAndCands(cells);
  }

  /**
   * toSaveString - to save board
   *
   * @return Board save string
   */
  public String toSaveString() {
    return Utility.stringCellSimple(cells);
  }

  @Override
  public Board clone() {
    Board tboard = new Board(this);

    return tboard;
  }
}
