package com.sudoku.contollers;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import com.sudoku.models.Board;
import com.sudoku.models.CellStatus;
import com.sudoku.models.Constants;
import com.sudoku.models.Logger;
import com.sudoku.models.Point;
import com.sudoku.models.SolveResult;
import com.sudoku.models.SolverMode;
import com.sudoku.models.Utility;

import lombok.Getter;

public class Creator {
  /** Logger class instance */
  private static Logger log = Logger.getLogger();

  /** Sudoku main board */
  @Getter
  private Board qboard;

  /** Sudoku answer board */
  @Getter
  private Board aboard;

  /** Sudoku game level */
  @Getter
  private int level = 0;

  /** Solver instance */
  @Getter
  private Solver solver = null;

  /** loop counter */
  @Getter
  private int loopCount = 0;

  /** Shuffle count */
  private final int SHUFFLE_COUNT = 2000;

  /** Flag if set check consistency for solver */
  private boolean checkConsistency = false;

  /** Fast mode, or judge level mode for solver */
  private SolverMode solverMode = SolverMode.FIND_MODE;

  /** delete counter for each level */
  private int [] delCountList = {10, 20, 30, 40, 50, 75, 75, 80, 80};  

  /**
   * Constructor (1) No parameter
   */
  public Creator() {
    checkConsistency = true;
    solverMode = SolverMode.FIND_MODE;
  }

  /**
   * Constructor (2)
   * @param checkConsistency
   * @param solverMode
   */
  public Creator(boolean checkConsistency, SolverMode solverMode) {
    this.checkConsistency = checkConsistency;
    this.solverMode = solverMode;
  }

  /**
   * create (1) - Create Sudoku Game No parameter
   */
  public void create() {
    // setup a starting board, filled 3 blocks but not all blocks yet
    Board board = startBoard(SHUFFLE_COUNT);

    // Solver(boolean checkConsistency, SolverMode solver mode)
    Solver solver = new Solver(false, SolverMode.FIND_MODE);
    qboard = solver.solve(board);
    create(qboard, Constants.DEL_COUNT_MAX);
  }
  
  /**
   * create (2) - Create Sudoku Game
   * @param requested difficulty level
   * @return
   */
  public int create(int reqLevel) {
    int level = 0;
    int delCount = Constants.DEL_COUNT_MAX ;
    if (reqLevel > 0 && reqLevel <= (delCountList.length - 1)) {
      delCount = delCountList[reqLevel];
    } else {
      delCount = delCountList[delCountList.length - 1];
    }
    Board qSave = null;
    Board aSave = null;
    for (int i = 0; i < 500; i++) {
      Board board = startBoard(SHUFFLE_COUNT);
      Solver solver = new Solver(false, SolverMode.FIND_MODE);
      Board tmpboard = solver.solve(board);
      Random rnd = new Random();
      int dCount = delCount + rnd.nextInt(9);
      int delNumber = 0;
      if (reqLevel > 4) {
        delNumber = rnd.nextInt(9) + 1;
      }
      level = create(tmpboard, dCount, delNumber);
      if (level >= (reqLevel - 1) && level <= (reqLevel + 1)) {
        qSave = qboard;
        aSave = aboard;
        // log.notice("Level:%d Loop:%d, DelCount:%d\n", level, i+1, dCount);
      }
      if (level == reqLevel) {
        log.notice("Level:%d Loop:%d, DelCount:%d\n", level, i+1, dCount);
        return level;
      }
    }
    qboard = qSave;
    aboard = aSave;
    return level;
  }

  /**
   * create (3) - Create Sudoku Game - ※ plan to delete this method
   * @param requested difficulty level
   * @param loopmax
   * @return
   */
  public int create(int rqlevel, int loopmax) {
    int maxlevel = 0;
    int level = 0;
    Board q = null;
    Board a = null;

    loopCount = loopmax;
    for (int i = 0; i < loopmax; i++) {
      Board board = startBoard(SHUFFLE_COUNT);

      // Solver(boolean checkConsistency, SolverMode solver mode)
      Solver solver = new Solver(false, SolverMode.FIND_MODE);
      Board tmpboard = solver.solve(board);
      int delNumber = 0;
      if (rqlevel > 4) {
        Random rnd = new Random();
        delNumber = rnd.nextInt(9) + 1;
      }
      level = create(tmpboard, Constants.DEL_COUNT_MAX, delNumber);
      if (maxlevel < level) {
        maxlevel = level;
        q = new Board(qboard);
        a = new Board(aboard);
      }
      if (level >= rqlevel) {
        loopCount = i;
        break;
      }
    }
    qboard = q;
    aboard = a;
    return maxlevel;
  }

  /**
   * create - Create Sudoku Game
   * @param board
   * @param delcount
   * @param delNumber
   * @return
   */
  private int create(Board board, int delcount, int delNumber) {
    // create sudoku
    qboard = delete(board, delcount, delNumber);

    // fill numbers of the board
    // Solver(boolean checkConsistency, SolverMode solverMode)
    // solver = new Solver(checkConsistency, solverMode);
    solver = new Solver(checkConsistency, solverMode);
    aboard = solver.solve(qboard);
    level = solver.getLevel();
    log.debug("level=%d\n", level);
    return level;
  }

  /**
   * create - Create Sudoku Game
   * @param board
   * @param delcount
   * @return
   */
  private void create(Board board, int delcount) {
    // create sudoku
    qboard = delete(board, delcount);

    // fill numbers of the board
    // Solver(boolean checkConsistency, SolverMode solverMode)
    // solver = new Solver(checkConsistency, solverMode);
    solver = new Solver(checkConsistency, solverMode);
    aboard = solver.solve(qboard);
    level = solver.getLevel();
    log.debug("level=%d\n", level);
  }

  /**
   * delete (1) - delete numbers to create a game
   * @param pboard
   * @param delcount
   * @param delNumber
   * @return
   */
  private Board delete(Board pboard, int delcount, int delNumber) {
    Board lboard = new Board(pboard);
    boxNo = 0;
    boxlist = Arrays.<Boolean>asList(true, true, true, true, true, true, true, true, true);

    if (delNumber != 0) {
      List<Point> plist = Utility.pickToDelNumberAll(lboard, delNumber);
      for (Point p : plist) {
        lboard.delete(p);
      }
    }

    int box = nextBox();
    for (int i = 0; delcount > 0; i++) {
      if (box < 0) {
        break;
      }
      Point p = Utility.pickToDelinBox(lboard, box);
      if (null == p) {
        boxlist.set(box, false);
        box = nextBox();
        continue;
      }
      int val = lboard.getCells()[p.y][p.x].getVal();
      if (!lboard.delete(p)) {
        log.info("Error to delete the number of %s\n", p);
        continue;
      }
      if (i <= 9) {
        delcount--;
        box = nextBox();
        continue;
      }
      // Solver solver = new Solver(true, SolverMode.FIND_MODE);
      Solver solver = new Solver(true, SolverMode.FAST_MODE);
      Board aBoard = solver.solve(lboard);
      if (null == aBoard) {
        lboard.placeVal(p, val);
        continue;
      } else if (null != aBoard && SolveResult.COMPLETED == Utility.isCompleted(aBoard)) {
        delcount--;
        box = nextBox();
        continue;
      } else {
        lboard.placeVal(p, val);
        lboard.getCells()[p.y][p.x].setStatus(CellStatus.REQUIRED);
        continue;
      }
    }
    return lboard;
  }
  
  /**
   * delete (2) - delete numbers to create a game
   * @param pboard
   * @param delcount
   * @return
   */
  private Board delete(Board pboard, int delcount) {
    Board lboard = new Board(pboard);
    boxNo = 0;
    boxlist = Arrays.<Boolean>asList(true, true, true, true, true, true, true, true, true);

    int box = nextBox();
    for (int i = 0; delcount > 0; i++) {
      if (box < 0) {
        break;
      }
      Point p = Utility.pickToDelinBox(lboard, box);
      if (null == p) {
        boxlist.set(box, false);
        box = nextBox();
        continue;
      }
      int val = lboard.getCells()[p.y][p.x].getVal();
      if (!lboard.delete(p)) {
        log.info("Error to delete the number of %s\n", p);
        continue;
      }
      if (i <= 9) {
        delcount--;
        box = nextBox();
        continue;
      }
      // Solver solver = new Solver(true, SolverMode.FIND_MODE);
      Solver solver = new Solver(true, SolverMode.FAST_MODE);
      Board aBoard = solver.solve(lboard);
      if (null == aBoard) {
        lboard.placeVal(p, val);
        continue;
      } else if (null != aBoard && SolveResult.COMPLETED == Utility.isCompleted(aBoard)) {
        delcount--;
        box = nextBox();
        continue;
      } else {
        lboard.placeVal(p, val);
        lboard.getCells()[p.y][p.x].setStatus(CellStatus.REQUIRED);
        continue;
      }
    }
    return lboard;
  }

  /**
   * next box 
   * @return
   */
  private List<Boolean> boxlist = null;
  private int boxNo = 0;
  private int nextBox() {
    int retv = -1;
    for (int i = 0; i < 9; i++) {
      if (boxlist.get(boxNo)) {
        retv = boxNo;
        boxNo = (boxNo + 1) % 9;
        return retv;
      } else {
        boxNo = (boxNo + 1) % 9;
      }
    }
    return retv;
  }

  /**
   * startBoard - setup a starting board, filled 3 blocks but not all blocks yet
   *
   * @param count - randomize swap count
   */
  private Board startBoard(int count) {
    int vals[];
    Board board = new Board();

    vals = randIntArray(count);
    board.setCellsValBlock(0, vals);
    vals = randIntArray(count);
    board.setCellsValBlock(4, vals);
    vals = randIntArray(count);
    board.setCellsValBlock(8, vals);
    return board;
  }

  /**
   * Generate randomized integer array
   *
   * @return randomized array
   */
  private int[] randIntArray(int count) {
    int vals[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

    Random rnd = new Random();
    for (int i = 0; i < count; i++) {
      int idx1 = rnd.nextInt(vals.length);
      int idx2 = rnd.nextInt(vals.length);
      int tmp = vals[idx1];
      vals[idx1] = vals[idx2];
      vals[idx2] = tmp;
    }
    return vals;
  }
}
