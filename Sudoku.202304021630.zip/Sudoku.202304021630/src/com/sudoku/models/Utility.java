package com.sudoku.models;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Utility {
  /** Logger instance */
  private static Logger log = Logger.getLogger();

  /**
   * Box's coordinates
   * +---+---+---+
   * |BOX|BOX|BOX|
   * | 0 | 1 | 2 |
   * +---+---+---+
   * |BOX|BOX|BOX|
   * | 3 | 4 | 5 |
   * +---+---+---+
   * |BOX|BOX|BOX|
   * | 6 | 7 | 8 |
   * +---+---+---+
   */
  private final static int boxes[][] = {
      { 0, 0 }, { 0, 1 }, { 0, 2 }, { 1, 0 }, { 1, 1 }, { 1, 2 }, { 2, 0 }, { 2, 1 }, { 2, 2 }, // 1
      { 0, 3 }, { 0, 4 }, { 0, 5 }, { 1, 3 }, { 1, 4 }, { 1, 5 }, { 2, 3 }, { 2, 4 }, { 2, 5 }, // 2
      { 0, 6 }, { 0, 7 }, { 0, 8 }, { 1, 6 }, { 1, 7 }, { 1, 8 }, { 2, 6 }, { 2, 7 }, { 2, 8 }, // 3
      { 3, 0 }, { 3, 1 }, { 3, 2 }, { 4, 0 }, { 4, 1 }, { 4, 2 }, { 5, 0 }, { 5, 1 }, { 5, 2 }, // 4
      { 3, 3 }, { 3, 4 }, { 3, 5 }, { 4, 3 }, { 4, 4 }, { 4, 5 }, { 5, 3 }, { 5, 4 }, { 5, 5 }, // 5
      { 3, 6 }, { 3, 7 }, { 3, 8 }, { 4, 6 }, { 4, 7 }, { 4, 8 }, { 5, 6 }, { 5, 7 }, { 5, 8 }, // 6
      { 6, 0 }, { 6, 1 }, { 6, 2 }, { 7, 0 }, { 7, 1 }, { 7, 2 }, { 8, 0 }, { 8, 1 }, { 8, 2 }, // 7
      { 6, 3 }, { 6, 4 }, { 6, 5 }, { 7, 3 }, { 7, 4 }, { 7, 5 }, { 8, 3 }, { 8, 4 }, { 8, 5 }, // 8
      { 6, 6 }, { 6, 7 }, { 6, 8 }, { 7, 6 }, { 7, 7 }, { 7, 8 }, { 8, 6 }, { 8, 7 }, { 8, 8 }, // 9
  };


  /**
   * Line's coordinates
   *
   * Note: Because switching x with y, this can be row's coordinates too.
   */
  private final static int lines[][] = {
      {0, 0}, {0, 1}, {0, 2}, {0, 3}, {0, 4}, {0, 5}, {0, 6}, {0, 7}, {0, 8}, // 1
      {1, 0}, {1, 1}, {1, 2}, {1, 3}, {1, 4}, {1, 5}, {1, 6}, {1, 7}, {1, 8}, // 2
      {2, 0}, {2, 1}, {2, 2}, {2, 3}, {2, 4}, {2, 5}, {2, 6}, {2, 7}, {2, 8}, // 3
      {3, 0}, {3, 1}, {3, 2}, {3, 3}, {3, 4}, {3, 5}, {3, 6}, {3, 7}, {3, 8}, // 4
      {4, 0}, {4, 1}, {4, 2}, {4, 3}, {4, 4}, {4, 5}, {4, 6}, {4, 7}, {4, 8}, // 5
      {5, 0}, {5, 1}, {5, 2}, {5, 3}, {5, 4}, {5, 5}, {5, 6}, {5, 7}, {5, 8}, // 6
      {6, 0}, {6, 1}, {6, 2}, {6, 3}, {6, 4}, {6, 5}, {6, 6}, {6, 7}, {6, 8}, // 7
      {7, 0}, {7, 1}, {7, 2}, {7, 3}, {7, 4}, {7, 5}, {7, 6}, {7, 7}, {7, 8}, // 8
      {8, 0}, {8, 1}, {8, 2}, {8, 3}, {8, 4}, {8, 5}, {8, 6}, {8, 7}, {8, 8}, // 9
  };

  private final static int iposBox1[][][] = {
      { {0, 0}, {1, 0}, {2, 0} }, { {3, 0}, {4, 0}, {5, 0} }, { {6, 0}, {7, 0}, {8, 0} },
      { {0, 1}, {1, 1}, {2, 1} }, { {3, 1}, {4, 1}, {5, 1} }, { {6, 1}, {7, 1}, {8, 1} },
      { {0, 2}, {1, 2}, {2, 2} }, { {3, 2}, {4, 2}, {5, 2} }, { {6, 2}, {7, 2}, {8, 2} },
      { {0, 3}, {1, 3}, {2, 3} }, { {3, 3}, {4, 3}, {5, 3} }, { {6, 3}, {7, 3}, {8, 3} },
      { {0, 4}, {1, 4}, {2, 4} }, { {3, 4}, {4, 4}, {5, 4} }, { {6, 4}, {7, 4}, {8, 4} },
      { {0, 5}, {1, 5}, {2, 5} }, { {3, 5}, {4, 5}, {5, 5} }, { {6, 5}, {7, 5}, {8, 5} },
      { {0, 6}, {1, 6}, {2, 6} }, { {3, 6}, {4, 6}, {5, 6} }, { {6, 6}, {7, 6}, {8, 6} },
      { {0, 7}, {1, 7}, {2, 7} }, { {3, 7}, {4, 7}, {5, 7} }, { {6, 7}, {7, 7}, {8, 7} },
      { {0, 8}, {1, 8}, {2, 8} }, { {3, 8}, {4, 8}, {5, 8} }, { {6, 8}, {7, 8}, {8, 8} },
  };

  private final static int iposBox2[][][] = {
      {{3,0},{4,0},{5,0},{6,0},{7,0},{8,0}},{{0,0},{1,0},{2,0},{6,0},{7,0},{8,0}},{{0,0},{1,0},{2,0},{3,0},{4,0},{5,0}},
      {{3,1},{4,1},{5,1},{6,1},{7,1},{8,1}},{{0,1},{1,1},{2,1},{6,1},{7,1},{8,1}},{{0,1},{1,1},{2,1},{3,1},{4,1},{5,1}},
      {{3,2},{4,2},{5,2},{6,2},{7,2},{8,2}},{{0,2},{1,2},{2,2},{6,2},{7,2},{8,2}},{{0,2},{1,2},{2,2},{3,2},{4,2},{5,2}},
      {{3,3},{4,3},{5,3},{6,3},{7,3},{8,3}},{{0,3},{1,3},{2,3},{6,3},{7,3},{8,3}},{{0,3},{1,3},{2,3},{3,3},{4,3},{5,3}},
      {{3,4},{4,4},{5,4},{6,4},{7,4},{8,4}},{{0,4},{1,4},{2,4},{6,4},{7,4},{8,4}},{{0,4},{1,4},{2,4},{3,4},{4,4},{5,4}},
      {{3,5},{4,5},{5,5},{6,5},{7,5},{8,5}},{{0,5},{1,5},{2,5},{6,5},{7,5},{8,5}},{{0,5},{1,5},{2,5},{3,5},{4,5},{5,5}},
      {{3,6},{4,6},{5,6},{6,6},{7,6},{8,6}},{{0,6},{1,6},{2,6},{6,6},{7,6},{8,6}},{{0,6},{1,6},{2,6},{3,6},{4,6},{5,6}},
      {{3,7},{4,7},{5,7},{6,7},{7,7},{8,7}},{{0,7},{1,7},{2,7},{6,7},{7,7},{8,7}},{{0,7},{1,7},{2,7},{3,7},{4,7},{5,7}},
      {{3,8},{4,8},{5,8},{6,8},{7,8},{8,8}},{{0,8},{1,8},{2,8},{6,8},{7,8},{8,8}},{{0,8},{1,8},{2,8},{3,8},{4,8},{5,8}},
  };

  private final static int iposBox3[][][] = {
      {{0,1},{1,1},{2,1},{0,2},{1,2},{2,2}},{{3,1},{4,1},{5,1},{3,2},{4,2},{5,2}},{{6,1},{7,1},{8,1},{6,2},{7,2},{8,2}},
      {{0,0},{1,0},{2,0},{0,2},{1,2},{2,2}},{{3,0},{4,0},{5,0},{3,2},{4,2},{5,2}},{{6,0},{7,0},{8,0},{6,2},{7,2},{8,2}},
      {{0,0},{1,0},{2,0},{0,1},{1,1},{2,1}},{{3,0},{4,0},{5,0},{3,1},{4,1},{5,1}},{{6,0},{7,0},{8,0},{6,1},{7,1},{8,1}},
      {{0,4},{1,4},{2,4},{0,5},{1,5},{2,5}},{{3,4},{4,4},{5,4},{3,5},{4,5},{5,5}},{{6,4},{7,4},{8,4},{6,5},{7,5},{8,5}},
      {{0,3},{1,3},{2,3},{0,5},{1,5},{2,5}},{{3,3},{4,3},{5,3},{3,5},{4,5},{5,5}},{{6,3},{7,3},{8,3},{6,5},{7,5},{8,5}},
      {{0,3},{1,3},{2,3},{0,4},{1,4},{2,4}},{{3,3},{4,3},{5,3},{3,4},{4,4},{5,4}},{{6,3},{7,3},{8,3},{6,4},{7,4},{8,4}},
      {{0,7},{1,7},{2,7},{0,8},{1,8},{2,8}},{{3,7},{4,7},{5,7},{3,8},{4,8},{5,8}},{{6,7},{7,7},{8,7},{6,8},{7,8},{8,8}},
      {{0,6},{1,6},{2,6},{0,8},{1,8},{2,8}},{{3,6},{4,6},{5,6},{3,8},{4,8},{5,8}},{{6,6},{7,6},{8,6},{6,8},{7,8},{8,8}},
      {{0,6},{1,6},{2,6},{0,7},{1,7},{2,7}},{{3,6},{4,6},{5,6},{3,7},{4,7},{5,7}},{{6,6},{7,6},{8,6},{6,7},{7,7},{8,7}},
  };

  /**
   * Box's coordinates array
   *
   */
  private final static Point boxarry[][] = {
      {new Point(0, 0), new Point(1, 0), new Point(2, 0), new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(0, 2), new Point(1, 2), new Point(2, 2)}, // 1
      {new Point(3, 0), new Point(4, 0), new Point(5, 0), new Point(3, 1), new Point(4, 1), new Point(5, 1), new Point(3, 2), new Point(4, 2), new Point(5, 2)}, // 2
      {new Point(6, 0), new Point(7, 0), new Point(8, 0), new Point(6, 1), new Point(7, 1), new Point(8, 1), new Point(6, 2), new Point(7, 2), new Point(8, 2)}, // 3
      {new Point(0, 3), new Point(1, 3), new Point(2, 3), new Point(0, 4), new Point(1, 4), new Point(2, 4), new Point(0, 5), new Point(1, 5), new Point(2, 5)}, // 4
      {new Point(3, 3), new Point(4, 3), new Point(5, 3), new Point(3, 4), new Point(4, 4), new Point(5, 4), new Point(3, 5), new Point(4, 5), new Point(5, 5)}, // 5
      {new Point(6, 3), new Point(7, 3), new Point(8, 3), new Point(6, 4), new Point(7, 4), new Point(8, 4), new Point(6, 5), new Point(7, 5), new Point(8, 5)}, // 6
      {new Point(0, 6), new Point(1, 6), new Point(2, 6), new Point(0, 7), new Point(1, 7), new Point(2, 7), new Point(0, 8), new Point(1, 8), new Point(2, 8)}, // 7
      {new Point(3, 6), new Point(4, 6), new Point(5, 6), new Point(3, 7), new Point(4, 7), new Point(5, 7), new Point(3, 8), new Point(4, 8), new Point(5, 8)}, // 8
      {new Point(6, 6), new Point(7, 6), new Point(8, 6), new Point(6, 7), new Point(7, 7), new Point(8, 7), new Point(6, 8), new Point(7, 8), new Point(8, 8)}, // 9
  };

  /**
   * Line's coordinates array
   *
   */
  private final static Point linearry[][] = {
      {new Point(0, 0), new Point(1, 0), new Point(2, 0), new Point(3, 0), new Point(4, 0), new Point(5, 0), new Point(6, 0), new Point(7, 0), new Point(8, 0)}, // 1
      {new Point(0, 1), new Point(1, 1), new Point(2, 1), new Point(3, 1), new Point(4, 1), new Point(5, 1), new Point(6, 1), new Point(7, 1), new Point(8, 1)}, // 2
      {new Point(0, 2), new Point(1, 2), new Point(2, 2), new Point(3, 2), new Point(4, 2), new Point(5, 2), new Point(6, 2), new Point(7, 2), new Point(8, 2)}, // 3
      {new Point(0, 3), new Point(1, 3), new Point(2, 3), new Point(3, 3), new Point(4, 3), new Point(5, 3), new Point(6, 3), new Point(7, 3), new Point(8, 3)}, // 4
      {new Point(0, 4), new Point(1, 4), new Point(2, 4), new Point(3, 4), new Point(4, 4), new Point(5, 4), new Point(6, 4), new Point(7, 4), new Point(8, 4)}, // 5
      {new Point(0, 5), new Point(1, 5), new Point(2, 5), new Point(3, 5), new Point(4, 5), new Point(5, 5), new Point(6, 5), new Point(7, 5), new Point(8, 5)}, // 6
      {new Point(0, 6), new Point(1, 6), new Point(2, 6), new Point(3, 6), new Point(4, 6), new Point(5, 6), new Point(6, 6), new Point(7, 6), new Point(8, 6)}, // 7
      {new Point(0, 7), new Point(1, 7), new Point(2, 7), new Point(3, 7), new Point(4, 7), new Point(5, 7), new Point(6, 7), new Point(7, 7), new Point(8, 7)}, // 8
      {new Point(0, 8), new Point(1, 8), new Point(2, 8), new Point(3, 8), new Point(4, 8), new Point(5, 8), new Point(6, 8), new Point(7, 8), new Point(8, 8)}, // 9
  };

  /**
   * Row's coordinates array
   *
   */
  private final static Point rowarry[][] = {
      {new Point(0, 0), new Point(0, 1), new Point(0, 2), new Point(0, 3), new Point(0, 4), new Point(0, 5), new Point(0, 6), new Point(0, 7), new Point(0, 8)}, // 1
      {new Point(1, 0), new Point(1, 1), new Point(1, 2), new Point(1, 3), new Point(1, 4), new Point(1, 5), new Point(1, 6), new Point(1, 7), new Point(1, 8)}, // 2
      {new Point(2, 0), new Point(2, 1), new Point(2, 2), new Point(2, 3), new Point(2, 4), new Point(2, 5), new Point(2, 6), new Point(2, 7), new Point(2, 8)}, // 3
      {new Point(3, 0), new Point(3, 1), new Point(3, 2), new Point(3, 3), new Point(3, 4), new Point(3, 5), new Point(3, 6), new Point(3, 7), new Point(3, 8)}, // 4
      {new Point(4, 0), new Point(4, 1), new Point(4, 2), new Point(4, 3), new Point(4, 4), new Point(4, 5), new Point(4, 6), new Point(4, 7), new Point(4, 8)}, // 5
      {new Point(5, 0), new Point(5, 1), new Point(5, 2), new Point(5, 3), new Point(5, 4), new Point(5, 5), new Point(5, 6), new Point(5, 7), new Point(5, 8)}, // 6
      {new Point(6, 0), new Point(6, 1), new Point(6, 2), new Point(6, 3), new Point(6, 4), new Point(6, 5), new Point(6, 6), new Point(6, 7), new Point(6, 8)}, // 7
      {new Point(7, 0), new Point(7, 1), new Point(7, 2), new Point(7, 3), new Point(7, 4), new Point(7, 5), new Point(7, 6), new Point(7, 7), new Point(7, 8)}, // 8
      {new Point(8, 0), new Point(8, 1), new Point(8, 2), new Point(8, 3), new Point(8, 4), new Point(8, 5), new Point(8, 6), new Point(8, 7), new Point(8, 8)}, // 9
  };

  /**
   * get the point of a box
   *
   * @param box - box number
   * @param no  - cell number of the box
   * @return point
   */
  public static Point boxPoint(int box, int no) {
    int y = Utility.boxes[box * 9 + no][0];
    int x = Utility.boxes[box * 9 + no][1];

    return new Point(x, y);
  }

  /**
   * get the point array of a box
   *
   * @param box - box number
   * @return point array
   */
  public static Point[] boxPointArry(int box) {
    return boxarry[box];
  }

  /**
   * get the point of a line
   *
   * @param line - line number
   * @param no   - cell number of the line
   * @return point
   */
  public static Point linePoint(int line, int no) {
    int y = Utility.lines[line * 9 + no][0];
    int x = Utility.lines[line * 9 + no][1];

    return new Point(x, y);
  }

  /**
   * get the point array of a line
   *
   * @param line - line number
   * @return point array
   */
  public static Point[] linePointArry(int line) {
    return linearry[line];
  }

  /**
   * get the point of a row
   *
   * @param row - row number
   * @param no  - cell number of the row
   * @return point
   */
  public static Point rowPoint(int row, int no) {
    int x = Utility.lines[row * 9 + no][0];
    int y = Utility.lines[row * 9 + no][1];

    return new Point(x, y);
  }

  /**
   * get the point array of a row
   *
   * @param row - row number
   * @return point array
   */
  public static Point[] rowPointArry(int row) {
    return rowarry[row];
  }

  /**
   * Pickup the pattern 1 box cell for the erase candidate
   *
   * @param rflag - reverse flag
   * @param y     - row
   * @param x1    - index1
   * @param x2    - index2
   * @return
   */
  public static Point pickPosBox1(boolean rflag, int y, int x1, int x2) {
    int xp, yp;
    if (rflag) {
      xp = Utility.iposBox1[y * 3 + x2][x1][0];
      yp = Utility.iposBox1[y * 3 + x2][x1][1];
    } else {
      yp = Utility.iposBox1[y * 3 + x2][x1][0];
      xp = Utility.iposBox1[y * 3 + x2][x1][1];
    }
    return new Point(xp, yp);
  }

  /**
   * Pickup the pattern 2 box cell for the erase candidate
   *
   * @param rflag - reverse flag
   * @param y     - row
   * @param x1    - index1
   * @param x2    - index2
   * @return
   */
  public static Point pickPosBox2(boolean rflag, int y, int x1, int x2) {
    int xp, yp;
    if (rflag) {
      xp = Utility.iposBox2[y * 3 + x2][x1][0];
      yp = Utility.iposBox2[y * 3 + x2][x1][1];
    } else {
      yp = Utility.iposBox2[y * 3 + x2][x1][0];
      xp = Utility.iposBox2[y * 3 + x2][x1][1];
    }
    return new Point(xp, yp);
  }

  /**
   * Pickup the pattern 3 box cell for the erase candidate
   *
   * @param rflag - reverse flag
   * @param y     - row
   * @param x1    - index1
   * @param x2    - index2
   * @return
   */
  public static Point pickPosBox3(boolean rflag, int y, int x1, int x2) {
    int xp, yp;
    if (rflag) {
      xp = Utility.iposBox3[y * 3 + x2][x1][0];
      yp = Utility.iposBox3[y * 3 + x2][x1][1];
    } else {
      yp = Utility.iposBox3[y * 3 + x2][x1][0];
      xp = Utility.iposBox3[y * 3 + x2][x1][1];
    }
    return new Point(xp, yp);
  }

  /**
   * Copy board
   *
   * @param d - destination
   * @param s - source
   */
  public static void copyBoard(Board d, Board s) {
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        d.getCells()[y][x].setVal(s.getCells()[y][x].getVal());
        d.getCells()[y][x].setCand(s.getCells()[y][x].getCand());
        d.getCells()[y][x].setStatus(s.getCells()[y][x].getStatus());
      }
    }
  }

  /**
   * Check if the board is completely filled
   *
   * @param board - Given board to be judged
   * @return Solved result
   */
  public static SolveResult isCompleted(Board board) {
    for (int n = 0; n < 9; n++) {
      int bbit = 0, lbit = 0, rbit = 0;
      for (int i = 0; i < 9; i++) {
        Point bp = boxPoint(n, i);
        Point lp = linePoint(n, i);
        Point rp = rowPoint(n, i);
        Cell bcell = board.getCells()[bp.y][bp.x];
        Cell lcell = board.getCells()[lp.y][lp.x];
        Cell rcell = board.getCells()[rp.y][rp.x];
        int bval = bcell.getBitVal();
        int lval = lcell.getBitVal();
        int rval = rcell.getBitVal();

        if (((bbit & bval) != 0) || ((lbit & lval) != 0) || ((rbit & rval) != 0)) {
          return SolveResult.FAILED;
        } else {
          bbit |= bval;
          lbit |= lval;
          rbit |= rval;
        }
      }
      if ((bbit != Constants.ALL_CAND_BITS) || (lbit != Constants.ALL_CAND_BITS) || (rbit != Constants.ALL_CAND_BITS)) {
        return SolveResult.IN_PROGRESS;
      }
    }
    return SolveResult.COMPLETED;
  }

  /**
   * Check if the board is consistency filled
   *
   * @param board - Given board to be judged
   * @return Solved result
   */
  public static SolveResult isConsistency(Board board) {
    // 1. if there is empty cell without candidate
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Cell cell = board.getCells()[y][x];
        if (cell.getVal() == 0 && cell.getCand() == 0)
          return SolveResult.FAILED;
      }
    }

    // 2. if there is in-consistency candidate bits in empties
    for (int n = 0; n < 9; n++) {
      int bbit = 0, bcand = 0, bempCount = 0;
      int lbit = 0, lcand = 0, lempCount = 0;
      int rbit = 0, rcand = 0, rempCount = 0;
      for (int i = 0; i < 9; i++) {
        Point bp = boxPoint(n, i);
        Point lp = linePoint(n, i);
        Point rp = rowPoint(n, i);
        Cell bcell = board.getCells()[bp.y][bp.x];
        Cell lcell = board.getCells()[lp.y][lp.x];
        Cell rcell = board.getCells()[rp.y][rp.x];
        // duplicate number check for box
        int bval = bcell.getBitVal();
        if (bval != 0) {
          if ((bbit & bval) != 0) {
            return SolveResult.FAILED;
          }
          bbit = bbit | bval;
        }
        bcand = bcand | bcell.getCand();
        bempCount = (bval == 0) ? bempCount + 1 : 0;
        // duplicate number check for line
        int lval = lcell.getBitVal();
        if (lval != 0) {
          if ((lbit & lval) != 0) {
            return SolveResult.FAILED;
          }
          lbit = lbit | lval;
        }
        lcand = lcand | lcell.getCand();
        lempCount = (lval == 0) ? lempCount + 1 : 0;
        // duplicate number for row
        int rval = rcell.getBitVal();
        if (rval != 0) {
          if ((rbit & rval) != 0) {
            return SolveResult.FAILED;
          }
          rbit = rbit | rval;
        }
        rcand = rcand | rcell.getCand();
        rempCount = (rval == 0) ? rempCount + 1 : 0;
      }

      // 3. number of candidates >empties
      if (countBits(bcand) < bempCount || countBits(lcand) < lempCount || countBits(rcand) < rempCount) {
        return SolveResult.FAILED;
      }
    }
    return SolveResult.IN_PROGRESS;
  }

  /**
   * Get candidate numbers of the cell
   *
   * @param cell
   * @param val  - val to be checked
   * @return
   */
  public static boolean isCandidate(Cell cell, int val) {
    boolean result = ((cell.getCand() & (1 << val)) != 0) ? true : false;
    return result;
  }

  /**
   * Get candidate numbers of the cell
   *
   * @param cell
   * @return Candidate numbers list
   */
  public static List<Integer> candList(Cell cell) {
    List<Integer> cands = new ArrayList<Integer>();
    int cand = cell.getCand();

    for (int i = 0; i < 9; i++) {
      if ((cand & (1 << i)) != 0) {
        cands.add(i + 1);
      }
    }
    return cands;
  }

  /**
   * Pick-up the cell to delete
   *
   * @param Board - Given board to delete
   * @param block - Block number to check
   * @return Point to be picked-up
   */
  public static Point pickToDelinBox(Board Board, int block) {
    List<Point> ps = new ArrayList<Point>();
    for (int i = 0; i < 9; i++) {
      int y = Utility.boxes[block * 9 + i][0];
      int x = Utility.boxes[block * 9 + i][1];
      Cell cell = Board.getCells()[y][x];
      if ((cell.getBitVal() != 0) && (cell.getStatus() == CellStatus.INIT)) {
        ps.add(new Point(x, y));
      }
    }

    if (ps.size() <= 0) {
      return null;
    }

    Random rnd = new Random();
    int idx = rnd.nextInt(ps.size());

    return ps.get(idx);
  }

  /**
   * Pick-up the cells to delete a number
   *
   * @param Board  - Given board to delete
   * @param number - a number to delete
   * @return Point to be picked-up
   */
  public static List<Point> pickToDelNumberAll(Board Board, int number) {
    List<Point> ps = new ArrayList<Point>();
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        Cell cell = Board.getCells()[y][x];
        if (cell.getVal() == number) {
          ps.add(new Point(x, y));
        }
      }
    }

    if (ps.size() <= 0) {
      return null;
    }
    return ps;
  }

  /**
   * Count bits
   *
   * @param val - Val to count bits
   * @return Bit counts
   */
  public static int countBits(int val) {
    val = (val & 0x55555555) + (val >> 1 & 0x55555555);
    val = (val & 0x33333333) + (val >> 2 & 0x33333333);
    val = (val & 0x0f0f0f0f) + (val >> 4 & 0x0f0f0f0f);
    val = (val & 0x00ff00ff) + (val >> 8 & 0x00ff00ff);
    return (val & 0x0000ffff) + (val >> 16 & 0x0000ffff);
  }

  /**
   * Gets ntz - Bit position from right
   *
   * @param val - bit value
   * @return ntz + 1
   */
  public static int getNtz(int val) {
    return countBits((~val) & (val - 1)) + 1;
  }

  /**
   * Compare board object
   *
   * @param s           - Board source to compare
   * @param d           - Board destination to compare
   * @param candCmpFlag - Flag if compare candidate too
   * @return true : same, false : not same
   */
  public static boolean cmpBoard(Board s, Board d, boolean candCmpFlag) {
    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        if (s.getCells()[y][x].getVal() != d.getCells()[y][x].getVal()) {
          return false;
        }
        if (candCmpFlag) {
          if (s.getCells()[y][x].getVal() == 0 || d.getCells()[y][x].getVal() == 0) {
            if (s.getCells()[y][x].getCand() != d.getCells()[y][x].getCand()) {
              return false;
            }
          }
        }
      }
    }
    return true;
  }

  /**
   * Compare board object
   *
   * @param bss - Board list source to compare
   * @param d   - Board destination to compare
   * @return Found the answer board number
   */
  public static int isStored(List<Board> bss, Board bd) {
    int ret = -1;

    for (Board bs : bss) {
      ret += 1;
      if (cmpBoard(bs, bd, false)) {
        return ret;
      }
    }
    return -1;
  }

  /**
   * @brief Get binary number string
   *
   * @param[in] t The number to convert
   * @param[in] n Binary length
   *
   * @return Converted string
   */
  public static String binString(int t, int n) {
    StringBuilder ret = new StringBuilder();

    int b = 1;
    for (int i = 0; i < n; i++) {
      ret.append(((t & b) != 0) ? "1" : "0");
      b = b << 1;
    }
    return new String(ret);
  }

  /**
   * stringCellSimple - Simple cells string to save to file
   *
   * @param cs Cell[][]
   * @return Board save string
   */
  public static String stringCellSimple(Cell[][] cs) {
    StringBuilder ret = new StringBuilder();

    for (int y = 0; y < 9; y++) {
      for (int x = 0; x < 9; x++) {
        char val = (char) ('0' + cs[y][x].getVal());
        ret.append(val);
      }
    }
    return new String(ret);
  }

  /**
   * stringCellVals - to display values of board
   *
   * @param cs Cell[][]
   * @return Board print string
   */
  public static String stringCellVals(Cell[][] cs) {
    StringBuilder ret = new StringBuilder();

    for (int y = 0; y < 9; y++) {
      if (y == 0) {
        ret.append(" +-------+-------+-------+\n");
      }
      ret.append(" |");
      for (int x = 0; x < 9; x++) {
        int val = cs[y][x].getVal();
        ret.append((val == 0) ? " -" : " " + (char) ('0' + val));
        if (((x - 2) % 3) == 0) {
          ret.append(((x != 0) ? " " : "") + "|");
        }
      }
      if (((y - 2) % 3) == 0) {
        ret.append("\n +-------+-------+-------+\n");
      } else {
        ret.append("\n");
      }
    }
    return new String(ret);
  }

  /**
   * stringCellCands - to display candidates of board
   *
   * @param cs Cell[][]
   * @return Candidate board print string
   */
  public static String stringCellCands(Cell[][] cs) {
    StringBuilder ret = new StringBuilder();

    for (int y = 0; y < 9; y++) {
      if (y == 0) {
        ret.append(" +-------------+-------------+-------------+\n");
      }
      ret.append(" |");
      for (int x = 0; x < 9; x++) {
        Cell c = cs[y][x];
        int val = c.getVal();
        ret.append((val != 0) ? " ___" : String.format(" %03X", c.getCand()));
        if (((x - 2) % 3) == 0) {
          ret.append(((x != 0) ? " " : "") + "|");
        }
      }
      if (((y - 2) % 3) == 0) {
        ret.append("\n +-------------+-------------+-------------+\n");
      } else {
        ret.append("\n");
      }
    }
    return new String(ret);
  }

  /**
   * stringCellｓAndCands - to display values & candidates of board
   *
   * @param cs Cell[][]
   * @return Candidate board print string
   */
  public static String stringCellｓAndCands(Cell[][] cs) {
    StringBuilder ret = new StringBuilder();

    for (int y = 0; y < 9; y++) {
      if (y == 0) {
        ret.append(" +-------+-------+-------+");
        ret.append(" +----------------------+----------------------+----------------------+\n");
      }
      ret.append(" |");
      for (int x = 0; x < 9; x++) {
        int val = cs[y][x].getVal();
        ret.append((val == 0) ? " -" : " " + (char) ('0' + val));
        if (((x - 2) % 3) == 0) {
          ret.append(((x != 0) ? " " : "") + "|");
        }
      }
      ret.append(" |");
      for (int x = 0; x < 9; x++) {
        Cell c = cs[y][x];
        int val = c.getVal();
        ret.append((val != 0) ? " ______" : String.format(" %s", c.getCandStr(6)));
        if (((x - 2) % 3) == 0) {
          ret.append(((x != 0) ? " " : "") + "|");
        }
      }
      if (((y - 2) % 3) == 0) {
        ret.append("\n +-------+-------+-------+");
        ret.append(" +----------------------+----------------------+----------------------+\n");
      } else {
        ret.append("\n");
      }
    }
    return new String(ret);
  }

  /**
   * Convert Db string to board class
   *
   * @param dbstr
   * @return board class
   */
  public static Board dbstrToBoard(String dbstr) {
    Board board = new Board();

    for (int i = 0; i < 9; i++) {
      int vals[] = parseBoard(dbstr, i);
      board.setCellsValLine(i, vals);
    }
    return board;
  }

  /**
   * Parse board lines
   *
   * @param lines
   * @param n
   * @return cells array
   */
  private static int[] parseBoard(String lines, int n) {
    int[] iret = new int[9];
    String line = "";
    try {
      line = lines.substring(n * 9, (n + 1) * 9);
      int idx = 0;
      for (char s : line.toCharArray()) {
        if (s >= '1' && s <= '9') {
          iret[idx++] = s - '0';
        } else {
          iret[idx++] = 0;
        }
      }
      return iret;
    } catch (Exception e) {
      log.error("SudokuFile.parseBoard(): Line:[%s] parse error", line);
    }
    return null;
  }

  /**
   * for debug
   *
   * @param s
   * @param n
   * @return
   */
  public static String strRepeat(String s, int n) {
    StringBuilder ret = new StringBuilder();

    for (int i = 0; i < n; i++) {
      ret.append(s);
    }
    return new String(ret);
  }

  /**
   * Get time stamp string
   *
   * @return
   */
  public static String timeStamp() {
    return new SimpleDateFormat("HH:mm:ss").format(new java.util.Date());
  }

  /**
   * Get date-time stamp string
   *
   * @return
   */
  public static String dateTimeStamp() {
    return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date());
  }
}
