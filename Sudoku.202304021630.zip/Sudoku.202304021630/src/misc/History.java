package misc;

import java.util.ArrayDeque;
import java.util.Deque;

import model.CellFx;

/**
 * 
 * @author npm091
 *
 */
public class History {
  /** singleton instance */
  private static History singleton = new History();

  private Deque<CellFx> stack = new ArrayDeque<CellFx>();

  /**
   * constructor - because singleton nothing to do
   */
  private History() {
  }

  public Boolean push(CellFx cell) {
    return stack.offerLast(cell);
  }

  public CellFx pop() {
    return stack.pollLast();
  }

  public CellFx dequeue() {
    return stack.pollFirst();
  }

  /**
   * Get instance
   *
   * @return
   */
  public static History getInstatnce() {
    return singleton;
  }

}
