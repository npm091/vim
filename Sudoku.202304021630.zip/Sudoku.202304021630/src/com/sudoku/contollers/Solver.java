package com.sudoku.contollers;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import com.sudoku.models.Board;
import com.sudoku.models.Constants;
import com.sudoku.models.Logger;
import com.sudoku.models.MultipleAswersException;
import com.sudoku.models.Point;
import com.sudoku.models.SolveResult;
import com.sudoku.models.SolverMode;
import com.sudoku.models.Utility;

import lombok.Getter;

/**
 * Solver class - Solve sudoku game
 *
 * @author npm091
 *
 */
public class Solver {
  /** Logger instance */
  private static Logger log = Logger.getLogger();

  /** Sudoku main board */
  public Board board;

  /** Sudoku answer board */
  public List<Board> ansBoard = new ArrayList<Board>();;

  /** Sudoku game level */
  @Getter
  private int level = 0;

  /** Backtrack read ahead depth */
  @Getter
  private int depth = 0;

  /** Maximum read ahead depth with backtrack */
  public int depth_max = 0;

  /** Read ahead depth at getting answer */
  public int depth_result = 0;

  /** Board stack for backtrack */
  public Deque<Board> stack = new ArrayDeque<Board>();

  /** Flag if set check consistency of given board */
  private boolean checkConsistency = true;

  /** Fast mode, or judge level mode */
  private SolverMode solverMode = SolverMode.FIND_MODE;

  /**
   * Constructor
   *
   * @param checkConsistency - Flag if set check consistency
   * @param solvermode       - Fast mode, or judge level mode
   */
  public Solver(boolean checkConsistency, SolverMode solverMode) {
    level = 0;
    depth = 0;
    depth_max = 0;
    depth_result = 0;
    this.checkConsistency = checkConsistency;
    this.solverMode = solverMode;
    board = new Board();
    ansBoard = new ArrayList<Board>();
  }

  /**
   * Solve sudoku board
   *
   * @param pboard - Game board to solve
   * @return Answer board
   */
  public Board solve(Board pboard) {
    level = 0;
    depth = 0;
    depth_max = 0;
    depth_result = 0;
    board = new Board();
    board.init(pboard);
    ansBoard = new ArrayList<Board>();
    fill(pboard, solverMode);
    if (ansBoard.size() == 1) {
      return ansBoard.get(0);
    }
    log.debug("wrong game\n");
    return null;
  }

  /**
   * Fill all the values in the board
   *
   * @param pboard    - Game board to solve
   * @param deepLevel - check routine level
   * @param sieveLoop - sieve repeat loop
   */
  private void fill(Board pboard, SolverMode solverMode) {
    Board lboard = new Board(pboard);

    List<Point> ps = lboard.sieveCells(true, solverMode);
    level = (level < 1) ? lboard.getLevel() : level;
    log.info("Solver.fill()\n");

    // Return if found answer
    if (ps.size() == 0 && SolveResult.COMPLETED == Utility.isCompleted(lboard)) {
      log.info("Solver.fill(): level:%d\n", level);
      ansBoard.add(lboard.clone());
      return;
    }

    // Search answer by back track method
    depth = 0;
    depth_result = 0;
    depth_max = 0;
    try {
      backtrack(lboard, ps);
      level = 4 + (depth_result + 1) / 2;
      log.debug("Solver.fill(): level:%d(%d)\n", level, ansBoard.size());
      // log.print("Solver.fill(): level:%d(%d,%d,%d)\n",
      // level, depth_max, depth_result, ansBoard.size());
    } catch (MultipleAswersException e) {
      level = 0;
      log.debug("Solver.fill(): %s\n", e);
    }
  }

  /**
   * Back track method - Call recursively with backtrackPlace method
   *
   * @param pboard - Game board to solve
   * @param ps     - Point list where can be placed value
   * @return Solving result
   * @throws MultipleAswersException - Exception when find out multiple answers
   */
  private SolveResult backtrack(Board pboard, List<Point> ps) throws MultipleAswersException {
    if (depth++ > Constants.MAX_DEPTH || null == ps || ps.size() == 0) {
      log.error("%sps is null\n", Utility.strRepeat("_", depth));
      depth--;
      return SolveResult.FAILED;
    }

    SolveResult result = SolveResult.IN_PROGRESS;
    // int n = 0;
    for (Point p : ps) {
      List<Integer> cands = Utility.candList(pboard.getCells()[p.y][p.x]);
      if (cands.size() > 0) {
        result = backtrackPlace(pboard, p, cands);
        // When answer found, break immediately if checker flag is NOT set
        if (checkConsistency != true && SolveResult.COMPLETED == result) {
          break;
        }
        // short cut
        if (SolveResult.FAILED == result) {
          break;
        }
      }
    }
    depth_max = (depth_max < depth) ? depth : depth_max;
    depth--;
    return result;
  }

  /**
   * backtrackPlace - Placing tentative answer and check consistency, Call
   * recursively with backtrackPlace method
   *
   * @param pboard - Game board to solve
   * @param ps     - Point list where can be placed value
   * @param cands  - candidate value list
   * @return Solving result
   * @throws MultipleAswersException - Exception when find out multiple answers
   */
  private SolveResult backtrackPlace(Board lboard, Point p, List<Integer> cands) throws MultipleAswersException {
    SolveResult result = SolveResult.IN_PROGRESS;

    // Try placing all the candidate answers
    for (Integer val : cands) {
      stack.push(lboard.clone());
      boolean res = lboard.placeVal(p, val);
      if (!res) {
        log.debug("Solver.backtrackPlace(): Contradiction, maybe system error\n");
        lboard = stack.pop();
        continue;
      }

      Board tboard = lboard.clone();
      List<Point> tps = tboard.sieveCells(true, SolverMode.FAST_MODE);
      result = Utility.isConsistency(tboard);
      if (SolveResult.IN_PROGRESS == result) {
        Utility.copyBoard(lboard, tboard);
        // log.info("Solver.backtrackPlace(): solving in progress\n");
        if (SolveResult.COMPLETED == Utility.isCompleted(lboard)) {
          // Check if the answer board is already registered
          depth_result = (depth_result < depth) ? depth : depth_result;
          if (Utility.isStored(ansBoard, lboard) < 0) {
            ansBoard.add(lboard.clone());
            if (ansBoard.size() > 1) {
              log.debug("Solver.backtrackPlace(): error wrong game\n");
              throw new MultipleAswersException();
            }
          }
          // When answer found, return immediately if checker flag is NOT set
          if (checkConsistency != true) {
            lboard = stack.pop();
            return SolveResult.COMPLETED;
          }
        }
        if (null != tps && tps.size() > 0) {
          result = backtrack(lboard, tps);
          // When answer found, return immediately if checker flag is NOT set
          if (checkConsistency != true && result == SolveResult.COMPLETED) {
            lboard = stack.pop();
            return SolveResult.COMPLETED;
          }
        }
        // Restore board
        lboard = stack.pop();
        continue;
      }
      // Restore board
      lboard = stack.pop();
    }
    return result;
  }
}
