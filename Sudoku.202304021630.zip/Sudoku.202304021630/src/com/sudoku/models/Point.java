package com.sudoku.models;

import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * Point class to specify location on board
 *
 * @author npm091
 *
 */
public class Point implements Comparable<Point> {
  /** Coordinate x */
  public int x;

  /** Coordinate y */
  public int y;

  /** Number of candidates */
  @Getter
  @Setter
  protected int cand;

  @Getter
  @Setter
  private int candCount;

  /**
   * Constructor
   *
   */
  public Point() {
    this.x = 0;
    this.y = 0;
    this.cand = 0;
    this.candCount = 0;
  }

  /**
   * Constructor
   *
   * @param x - Coordinate x
   * @param y - Coordinate y
   */
  public Point(int x, int y) {
    this.x = x;
    this.y = y;
    this.cand = 0;
    this.candCount = 0;
  }

  /**
   * Get Candidate List
   * 
   * @return
   */
  public List<Integer> getCandList() {
    List<Integer> list = new ArrayList<Integer>();
    int x = 1;
    for (int i = 0; i < 9; i++) {
      if ((this.cand & (x << i)) != 0) {
        list.add(i + 1);
      }
    }
    return list;
  }

  /**
   * toString
   *
   * @return toString for Point class
   */
  public String toString() {
    return String.format("(%d,%d)", this.x, this.y);
  }

  @Override
  public int compareTo(Point p) {
    return this.candCount - p.candCount;
  }
}
