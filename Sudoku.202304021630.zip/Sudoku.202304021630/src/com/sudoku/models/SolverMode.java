package com.sudoku.models;

/**
 * @author npm091
 *
 * Solver mode - 2nd parameter of Solver constructor
 *
 */
public enum SolverMode {
  /** Just sieve candidates, but not find out answer */
  FAST_MODE,

  /** Find out answer, but ignore level */
  FIND_MODE,

  /** Decide game difficulty level nut slow */
  JUDGE_LEVEL,

  /** only for debug */
  COMPLETE_LEVEL,
}
