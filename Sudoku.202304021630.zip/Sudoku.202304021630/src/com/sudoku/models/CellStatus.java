package com.sudoku.models;

/**
 * @author npm091
 *
 * Cell status
 */
public enum CellStatus {
  /** Cells status INIT */
  INIT,

  /** Cells status INIT */
  STAY,

  /** Cells status DELETED */
  DELETED,

  /** Cells status REQUIRED (Can't be deleted) */
  REQUIRED

}
