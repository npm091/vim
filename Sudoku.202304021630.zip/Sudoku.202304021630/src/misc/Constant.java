package misc;

import javafx.scene.paint.Color;

/**
 * Description - Constants definition
 */
public class Constant {
  /** Game mode parameters */
  public static final Integer BEFORE_START = 0;
  public static final Integer GAME_MODE = 1;
  public static final Integer CREATION_MODE = 2;

  /** Log level parameters */
  public static final int LEVEL_ERROR = 0;
  public static final int LEVEL_NOTICE = 1;
  public static final int LEVEL_INFO = 2;
  public static final int LEVEL_DEBUG = 3;
  
  /** Common Graphic Parameters */
  public static final Integer BS = 9; // Cell Numbers of X, Y
  public static final Integer BBS = 3; // Board Size
  public static final Double BBR = 2.5; // Board Ratio
  public static final Double DS = 50.0; // Common Cell Size
  public static final Double STT_X = 30.0; // Board Start Position X 
  public static final Double STT_Y = 50.0; // Board Start Position Y
  public static final Double DX = DS; // Cell Size X
  public static final Double DY = DS; // Cell Size Y
  public static final Double GAP = 1.0; // Gap between Cells
  public static final Double SCRN_SIZE_X = (BS * (DX + GAP + GAP / 9)) + STT_X * 2; // Screen Size X
  public static final Double SCRN_SIZE_Y = (BS * (DY + GAP + GAP / 9)) + STT_Y * 2; // Screen Size Y
  public static final Color BOARD_COLOR = Color.STEELBLUE; // Board Color
  public static final Color RECT_NORMAL_COLOR = Color.rgb(250, 250, 235); // Cell Color
  public static final Color RECT_CLICK_COLOR = Color.LIGHTGREEN;
  public static final Color RECT_MARKED_COLOR = Color.LIGHTSKYBLUE;
  public static final Color RECT_CURSOR_COLOR = Color.CYAN;
  public static final Color RECT_STROKE_COLOR = Color.BLACK; // Cell Stroke Color
  
  /** Cell Graphic Parameters */
  public static final Color CELL_ORG_COLOR = Color.BLACK;
  public static final Color CELL_COMMIT_COLOR = Color.LIGHTGREEN;
  public static final Color CELL_CAND_COLOR = Color.LIGHTSKYBLUE;
  public static final Color CELL_TEMP_COLOR = Color.DEEPSKYBLUE;
  public static final Color CELL_STROKE_COLOR = Color.BLACK;
  public static final String CELL_NUM_FONT = "メイリオ";
  public static final Integer CELL_NUM_FONT_SIZE = 50;
  public static final String CELL_CAND_FONT = "Courier New";
  public static final Integer CELL_CAND_FONT_SIZE = 14;
}
