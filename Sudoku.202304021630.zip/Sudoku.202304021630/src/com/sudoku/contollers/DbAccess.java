package com.sudoku.contollers;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.sudoku.models.Board;
import com.sudoku.models.DbBoard;
import com.sudoku.models.Logger;

/**
 * Sudoku File read and write answer
 *
 * @author npm091
 *
 */
public class DbAccess {
  /** Logger instance */
  private static Logger log = Logger.getLogger();

  /** mysql access parameters */
  private static final String URL = "jdbc:mysql://localhost:3306/public?allowPublicKeyRetrieval=true&useSSL=false";
  private static final String USERNAME = "public";
  private static final String PASSWORD = "public";
  private Connection connection = null;
  private Statement stmt_select = null;
  private PreparedStatement stmt_append = null;

  /**
   * Constructor - No read Sudoku data file
   *
   */
  public DbAccess() {
    try {
      connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
      connection.setAutoCommit(false);
    } catch (SQLException e) {
      log.error("DbAccess.initdb(): connection errorr");
    }
  }

  /**
   * Get game boards specified by id
   *
   * @param n - Game number
   * @return Game board object
   */
  public DbBoard getid(int id) {
    List<DbBoard> boards = select("select * from sudoku where id = %d", id);
    return boards.get(0);
  }

  /**
   * Get 10 game boards
   *
   * @param n - Game number
   * @return Game board object
   */
  public List<DbBoard> get() {
    return get(10);
  }

  /**
   * Get game boards
   *
   * @param n - Game number
   * @return Game board object
   */
  public List<DbBoard> get(int n) {
    return select("select * from sudoku order by qboard limit %d", n);
  }

  /**
   * Get game boards
   *
   * @param level
   * @param n     - Game number
   * @return Game board object
   */
  public List<DbBoard> get(int level, int n) {
    return select("select * from sudoku where level=%d order by qboard limit %d", level, n);
  }

  /**
   * Insert question board to database
   *
   * @param solver     - Solver object
   * @param resultFile
   */
  public void append(Board qboard) {
    String qbstr = qboard.toSaveString();
    List<DbBoard> boards = select("select * where qboard='%s'", qboard);
    String sql = "";

    try {
      if (boards.size() == 0) {
        sql = "INSERT INTO sudoku (createDate, qboard) VALUES (now(), ?)";
        stmt_append = connection.prepareStatement(sql);
        stmt_append.setString(1, qbstr);
        stmt_append.addBatch();
      }
      dbcommit(stmt_append);
      log.info("DbAccess.append(): %s\n", stmt_append);
    } catch (SQLException e) {
      log.error("DbAccess.append(): inserting error\n%s\n", e);
    }
  }

  /**
   * Insert complete data to database
   *
   * @param qboard
   * @param aboard
   * @param level
   */
  public void append(Board qboard, Board aboard, int level) {
    String qbstr = qboard.toSaveString();
    String abstr = aboard.toSaveString();
    List<DbBoard> boards = select("select * from sudoku where qboard='%s'", qbstr);

    if (boards.size() > 0) {
      log.error("DbAccess.append(): duplicated data\n");
      return;
    }

    String sql = "INSERT INTO sudoku (createDate, level, qboard, aboard) VALUES (now(), ?, ?, ?)";
    try {
      stmt_append = connection.prepareStatement(sql);
      stmt_append.setInt(1, level);
      stmt_append.setString(2, qbstr);
      stmt_append.setString(3, abstr);
      stmt_append.addBatch();
      dbcommit(stmt_append);
      log.info("DbAccess.append(): %s\n", stmt_append);
    } catch (SQLException e) {
      log.error("DbAccess.append(): inserting error\n%s\n", e);
    }
  }

  /**
   * Update board to database
   *
   * @param qboard
   * @param aboard
   * @param level
   */
  public void update(Board qboard, Board aboard, int level) {
    String qbstr = qboard.toSaveString();
    String abstr = aboard.toSaveString();
    List<DbBoard> boards = select("select * from sudoku where qboard='%s'", qbstr);

    if (boards.size() != 1) {
      log.error("DbAccess.update(): No data or duplicated data ()%d\n", boards.size());
      return;
    }

    String sql = "UPDATE sudoku set updateDate=now(), level=?, aboard=? WHERE qboard=?";
    try {
      stmt_append = connection.prepareStatement(sql);
      stmt_append.setInt(1, level);
      stmt_append.setString(2, abstr);
      stmt_append.setString(3, qbstr);
      stmt_append.addBatch();
      dbcommit(stmt_append);
      log.info("DbAccess.append(): %s\n", stmt_append);
    } catch (SQLException e) {
      log.error("DbAccess.append(): inserting error\n%s\n", e);
    }
  }

  /**
   * Get game boards with spcific number
   *
   * @param n - Game number
   * @return Game board object
   */
  private List<DbBoard> select(String fmt, Object... args) {
    String sql = String.format(fmt, args);
    List<DbBoard> boards = new ArrayList<DbBoard>();
    try {
      stmt_select = (null == stmt_select) ? connection.createStatement() : stmt_select;
      ResultSet rs = stmt_select.executeQuery(sql);
      while (rs.next()) {
        DbBoard board = new DbBoard();
        board.setId(rs.getInt("id"));
        board.setCreateDate(rs.getTimestamp("createDate"));
        board.setUpdateDate(rs.getTimestamp("updateDate"));
        board.setQboard(rs.getString("qboard"));
        board.setAboard(rs.getString("aboard"));
        board.setLevel(rs.getInt("Level"));
        boards.add(board);
      }
    } catch (SQLException ex) {
      log.error("SQLException: " + ex.getMessage());
      log.error("SQLState: " + ex.getSQLState());
      log.error("VendorError: " + ex.getErrorCode() + "\n");
      return null;
    }
    return boards;
  }

  /**
   * Commit modification to database
   *
   */
  public void dbcommit() {
    dbcommit(stmt_append);
  }

  /**
   * Commit modification to database
   *
   * @param stmt - Prepared statement
   */
  public void dbcommit(PreparedStatement stmt) {
    try {
      try {
        int[] result = stmt.executeBatch();
        log.notice("DbAccess.qbwriterdb(): inserted %d rows\n", result.length);
        connection.commit();
      } catch (SQLException e) {
        connection.rollback();
        log.error("DbAccess.qbwriterdb(): insert execute errorr");
      }
    } catch (SQLException e) {
      log.error("DbAccess.qbwriterdb(): inserting errorr");
    }
  }
}
