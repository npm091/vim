package com.sudoku.models;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;

import lombok.Getter;
import lombok.Setter;

/**
 * DbBoard class - Sudoku board
 *
 * @author npm091
 *
 */
public class DbBoard {
  /**
   * Create date
   */
  @Getter
  @Setter
  private Integer id;

  /**
   * Create date
   */
  @Setter
  private Timestamp createDate;

  /**
   * Update date
   */
  @Setter
  private Timestamp updateDate;

  /**
   * Game level
   */
  @Getter
  @Setter
  private Integer level;

  /**
   * Question board
   */
  @Getter
  @Setter
  private String qboard;

  /**
   * Answer board
   */
  @Getter
  @Setter
  private String aboard;

  /**
   * Constructor
   */
  public DbBoard() {

  }

  /**
   * Constructor
   */
  public DbBoard(Integer id, Timestamp createDate, Timestamp updateDate, Integer level, String qboard, String aboard) {
    this.id = id;
    this.createDate = createDate;
    this.updateDate = updateDate;
    this.level = level;
    this.qboard = qboard;
    this.aboard = aboard;
  }

  /**
   * Return formatted timestamp string
   * 
   * @return
   */
  public String getCreateDate() {
    if (null != createDate) {
      return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(createDate);
    }
    return "";
  }

  /**
   * Return formatted timestamp string
   * 
   * @return
   */
  public String getUpdateDate() {
    if (null != updateDate) {
      return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(updateDate);
    }
    return "";
  }

  /**
   * Return question board
   *
   * @return Question board
   */
  public Board qBoard() {
    return Utility.dbstrToBoard(qboard);
  }

  /**
   * Return answer board
   *
   * @return Answer board
   */
  public Board aBoard() {
    return Utility.dbstrToBoard(aboard);
  }

  /**
   * Question board print string
   *
   * @return board print string
   */
  public String qString() {
    return Utility.dbstrToBoard(qboard).toString();
  }

  /**
   * Answer board print string
   *
   * @return board print string
   */
  public String aString() {
    return Utility.dbstrToBoard(aboard).toString();
  }
}
