package model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sudoku.models.Board;
import com.sudoku.models.Cell;
import com.sudoku.models.Logger;

import application.Game;
import application.GameMode;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ToolBar;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.ScrollEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import misc.Constant;
import misc.History;
import misc.Utils;

/**
 * Board Class for Board Game
 *  
 * @author npm091
 * 
 * @since 2022/Mar/06th
 * @version 1.0 - 2022/Mar/12th
 */
public class BoardFx extends Constant {
  //------------------------------------------------------------------------------
  //- Constants and Variables
  //------------------------------------------------------------------------------
  /** Logger Class Instance */
  private static Logger log = Logger.getLogger();

  /** Logger Class Instance */
  private static History history = History.getInstatnce();

  // Window Title
  private static String TITLE = "Sudoku Board Game";

  // Menu Enable Flag List for Each Game Mode
  private Map<Integer, Boolean[]> menuFlagMap = new HashMap<Integer, Boolean[]>() {
    private static final long serialVersionUID = 1L;

    {
      put(GameMode.BEFORE_START, new Boolean[] { true, true, false, true, false, false, false, false, true });
      put(GameMode.GAME_MODE, new Boolean[] { true, false, true, false, true, true, true, true, true });
      put(GameMode.CREATION_MODE, new Boolean[] { false, false, true, true, true, true, true, true, true });
    }
  };

  // JavaFX Stage/Scene/SceneGraph Parameters
  private Stage stage;
  private Scene scene;
  private Group root;
  // Board Parameters
  private static int[] nlist = {1, 2, 3, 4, 5, 6, 7, 8, 9};
  private static String EMP_CANDIDATES = "         ";

  /** Turn Counter */
  // private Integer turnCount = 0;

  /** Cells for Numbers */
  private CellFx[][] cellXs = new CellFx[BS][BS];
  /** Current Mouse Pointed X */
  private Integer pointX = null;
  /** Current Mouse Pointed Y */
  private Integer pointY = null;

  // Tool Bar Menu List
  private Button mNew = new Button("New");
  private Button mLoad = new Button("Load");
  private Button mSave = new Button("Save");
  private Button mCreate = new Button("Create");
  private Button mUndo = new Button("Undo");
  private Button mCheck = new Button("Check");
  private Button mEnHint = new Button("Toggle Hint");
  private Button mDisHint = new Button("Disable Hint");
  private Button mClose = new Button("Close");
  private Button[] buttonList = { mNew, mLoad, mSave, mCreate, mUndo, mCheck, mEnHint, mDisHint, mClose };

  //------------------------------------------------------------------------------
  //- Constructors and Initializers
  //------------------------------------------------------------------------------
  /**
   * Constructor
   * 
   */
  public BoardFx() {
  }

  /**
  * Constructor - Display Game Board
  * 
  * @param prmStage - Primary Stage
  */
  public BoardFx(Stage prmStage) {
    initCells();
    stage = prmStage;
    stage.setTitle(TITLE);
    stage.setResizable(false);
    root = new Group();
    // Place the Menu Tool Bar
    root.getChildren().add(createMenuToolBar());
    // Place all the Cells (including rectangle, number and candidate) 
    for (int p[] : Utils.getAllCoord()) {
      int y = p[0];
      int x = p[1];
      Double xs = x * (DX + GAP) + BBR * (x / BBS) * GAP + STT_X;
      Double ys = y * (DY + GAP) + BBR * (y / BBS) * GAP + STT_Y;
      Rectangle rect = new Rectangle(xs, ys, DX, DY);
      rect.setFill(RECT_NORMAL_COLOR);
      rect.setStroke(RECT_STROKE_COLOR);
      cellXs[y][x].setRect(rect);
      root.getChildren().addAll(rect);
      root.getChildren().add(cellXs[y][x].getTxtNum());
      root.getChildren().add(cellXs[y][x].getTxtCand());
    }
    scene = new Scene(root, SCRN_SIZE_X, SCRN_SIZE_Y, BOARD_COLOR);
    // Resist Event Handlers
    scene.setOnMouseClicked(this::mousClickHandler);
    scene.setOnMouseMoved(this::mouseMoveHandler);
    scene.setOnScroll(this::mouseWheelHandler);
    scene.setOnKeyPressed(this::keyPressed);
    stage.setScene(scene);
    stage.show();
    setMenuStatus(GameMode.getMode());
  }

  /**
   * Create Main Menu Button Bar
   * 
   * @return
   */
  public Node createMenuToolBar() {
    ToolBar toolBar = new ToolBar();
    toolBar.getItems().addAll(mNew, mLoad, mSave, mCreate, mUndo, mCheck, mEnHint, mDisHint, mClose);

    // New Button Event Handler to Start New Game
    mNew.setOnMouseClicked(this::newGame);

    // Load Button Event Handler to Load Game
    mLoad.setOnMouseClicked(this::loadGame);

    // Save Button Event Handler to Save Game
    mSave.setOnMouseClicked(this::saveGame);

    // Create Button Event Handler to Create Game
    mCreate.setOnMouseClicked(this::createGame);

    // Undo Button Event Handler to Undo Turn
    mUndo.setOnMouseClicked(this::undoTurn);

    // Check Button Event Handler to Check Turn
    mCheck.setOnMouseClicked(this::checkTurn);

    // Toggle Hint Button Event Handler to Toggle Hint
    mEnHint.setOnMouseClicked(this::toggleHint);

    // Disable Hint Button Event Handler to Disable Hint
    mDisHint.setOnMouseClicked(this::disableHint);

    // Close Button Event Handler to Close Program  
    mClose.addEventHandler(ActionEvent.ACTION, e -> stage.close());

    return toolBar;
  }

  /**
   * Set Tool Bar Menu Status
   * 
   * @param mode
   */
  private void setMenuStatus(Integer mode) {
    Boolean[] list = menuFlagMap.get(mode);
    for (int n = 0; n < list.length; n++) {
      buttonList[n].setDisable(!list[n]);
    }
  }

  /**
   * Initialize Cells
   */
  private void initCells() {
    // turnCount = 0;
    for (int p[] : Utils.getAllCoord()) {
      int y = p[0];
      int x = p[1];
      cellXs[y][x] = new CellFx(y, x, getGY(y), getGX(x));
    }
  }

  /**
   * Place Original Number
   * 
   * @param y
   * @param x
   * @param val
   */
  public void placeOrg(int y, int x, int val) {
    CellFx cell = cellXs[y][x];
    cell.setVal(val);
    cell.setOrgFlag(true);
  }

  /**
   * Clear cell 
   * 
   * @param y
   * @param x
   */
  public void clrCell(int y, int x) {
    CellFx cell = cellXs[y][x];
    cell.clear();
  }

  /**
   * Place Candidate Numbers
   * 
   * @param y
   * @param x
   * @param candList
   */
  public void placeCand(int y, int x, List<Integer> candList) {
    String candStr = "";
    for (int i = 1; i <= BS; i++) {
      if (candList != null && candList.contains(i)) {
        candStr = candStr + String.valueOf(i) + " ";
      } else {
        candStr = candStr + "  ";
      }
      if ((i % 3) == 0) {
        candStr = candStr + "\n";
      }
    }
    CellFx cell = cellXs[y][x];
    cell.setCand(candStr);
  }

  //------------------------------------------------------------------------------
  //- Board Manipulate Methods
  //------------------------------------------------------------------------------
  /**
   * New Button Event Handler to Start New Game
   * 
   * @param e
   */
  Board gameBoard = null;
  Board solveBoard = null;

  /**
   * Start New Game
   * 
   * @param e
   */
  private void newGame(MouseEvent e) {
    log.println("New Game");
    try {
      clrCellColor();
      Game creator = new Game();
      gameBoard = creator.qboard;
      Cell[][] cells = gameBoard.getCells();
      for (int p[] : Utils.getAllCoord()) {
        int y = p[0];
        int x = p[1];
        Cell cell = cells[y][x];
        clrCell(y, x);
        if (cell.getVal() > 0) {
          placeOrg(y, x, cell.getVal());
        }
      }
      creator.analyzer(gameBoard, 4, 0);
      solveBoard = creator.qboard;
      //set game mode to GAME_MODE
      setMenuStatus(GameMode.setGameMode(GameMode.GAME_MODE));
      // turnCount = 0;
    } catch (Exception err) {
      log.error("system error in newGame()  %s\n", err);
    }
  }
  /**
   * Load Button Event Handler to Start New Game
   * 
   * @param e
   */
  private void loadGame(MouseEvent e) {
    log.println("Load Game - Not Implemented");
  }

  /**
   * Save Button Event Handler to Save Game
   * 
   * @param e
   */
  private void saveGame(MouseEvent e) {
    log.println("Save Game - Not Implemented");
  }

  /**
   * Create Button Event Handler to Create Game
   * 
   * @param e
   */
  private void createGame(MouseEvent e) {
    log.println("Create Game - Not Implemented");
  }

  /**
   * Undo Button Event Handler to Undo Turn
   * 
   * @param e
   */
  private void undoTurn(MouseEvent e) {
    log.println("Undo Turn - Not Implemented");
  }

  /**
   * Check Button Event Handler to Check Turn
   * 
   * @param e
   */
  private void checkTurn(MouseEvent e) {
    log.println("Check Turn - Not Implemented");
  }

  /**
   * Toggle Hint Button Event Handler to Enable Hint
   * 
   * @param e
   */
  private static boolean hintFlag = false; 
  private void toggleHint(MouseEvent e) {
    log.println("Toggle Hint: " + !hintFlag);
    if (gameBoard == null) {
      return;
    }
    Cell[][] cells = gameBoard.getCells();
    for (int p[] : Utils.getAllCoord()) {
      Cell cell = cells[p[0]][p[1]];
      CellFx cellx = cellXs[p[0]][p[1]];
      if (!hintFlag && cell.getVal() == 0 && cellx.getVal() == null) {
        placeCand(cell.y, cell.x, cell.getCandList());
        log.debug("pcell[%d][%d]=%d\n", cell.y, cell.x, cell.getVal());
      } else {
        placeCand(cell.y, cell.x, null);
      }
    }
    hintFlag = !hintFlag;
  }

  /**
   * Disable Hint Button Event Handler to Disable Hint
   * 
   * @param e
   */
  private void disableHint(MouseEvent e) {
    log.println("Disable Hint - Not Implemented");
  }

  /**
   * Key Input Event
   * 
   * @param e
   */
  private void keyPressed(KeyEvent e) {
    try {
      String s = e.getText();
      Integer val = Integer.parseInt(s);
      if (val > 0 && val < 10) {
        CellFx cell = cellXs[pointY][pointX];
        cell.setVal(val);
        cell.setCommFlag(false);
        log.debug("Committed - Cell[%d][%d]=%d\n", pointY, pointX, cell.getVal());
      }
    } catch (Exception ex) {
      log.debug("system eror in keyPressed()  %s\n", ex);
    }
  }

  /**
   * Event Handler for Mouse Wheel
   * 
   * @param e
   */
  private void mouseWheelHandler(ScrollEvent e) {
    if (GameMode.BEFORE_START == GameMode.getMode()) {
      return;
    }
    Double gx = e.getX();
    Double gy = e.getY();
    Integer ix = getIX(gx);
    Integer iy = getIY(gy);
    if (gx > STT_X && gy > STT_Y && ix >= 0 && ix < BS && iy >= 0 && iy < BS) {
      CellFx cell = cellXs[iy][ix];
      if (!cell.getOrgFlag()) {
        if (e.getDeltaY() < 0) {
          cell.setVal(cell.incrementVal(BS));
          log.notice("val+=%d\n",cell.getVal() );
        } else if (e.getDeltaY() > 0) {
          cell.setVal(cell.decrementVal());
          log.notice("val-=%d\n",cell.getVal() );
        }
        cell.setCommFlag(false);
        log.debug("Cell[%d][%d]=%d\n", iy, ix, cell.getVal());
      }
    }
  }

  /**
   * Event Handler for Mouse Move
   * 
   * @param e
   */
  private void mouseMoveHandler(MouseEvent e) {
    Double gx = e.getX();
    Double gy = e.getY();
    Integer ix = getIX(gx);
    Integer iy = getIY(gy);
    if (gx > STT_X && gy > STT_Y && ix >= 0 && ix < BS && iy >= 0 && iy < BS) {
      if (pointX != null && pointY != null && (ix != pointX || iy != pointY)) {
        CellFx pointCell = cellXs[pointY][pointX];
        if (!pointCell.getCommFlag()) {
          // log.println("move1");
          pointCell.setVal(null);
        } else {
          // log.println("move2");
        }
        clrCellColor();
        setCellColor(cellXs[iy][ix], RECT_CURSOR_COLOR);
      }
      pointX = ix;
      pointY = iy;
    }
  }

  /**
   * Event Handler for Mouse Click
   * 
   * @param e - MouseEvent parameter
   */
  private void mousClickHandler(MouseEvent e) {
    MouseButton b = e.getButton();
    if (b == MouseButton.PRIMARY) {
      log.println("left clicked a cell");
      clickCell(e.getX(), e.getY());
    } else if (b == MouseButton.SECONDARY) {
      log.println("right clicked a cell");
      clrCellColor();
      setCandidates(e.getX(), e.getY());
    }
  }

  public void mousClickHandlerPrev(MouseEvent e) {
    if (GameMode.BEFORE_START == GameMode.getMode()) {
      return;
    }
    Double gx = e.getX();
    Double gy = e.getY();
    Integer ix = getIX(gx);
    Integer iy = getIY(gy);
    log.println("%s\n", e.getButton());
    if (gx > STT_X && gy > STT_Y && ix >= 0 && ix < BS && iy >= 0 && iy < BS) {
      CellFx cell = cellXs[iy][ix];
      if (cell.getVal() != null && !cell.getOrgFlag()) {
        cell.setCommFlag(true);
        history.push(cell);
        Cell c = solveBoard.getCells()[iy][ix];
        log.debug("Commit-Cell[%d][%d]=%d %s\n", iy, ix, cell.getVal(), c.getCandList());
      }
    }
  }

  /**
   * Calculate ix from coordinate x
   * 
   * @param x
   * @return ix
   */
  private Integer getIX(Double x) {
    Integer ix = (int) ((x - STT_X) / (DX + GAP));
    ix = (int) ((x - STT_X - (ix / BBS) * GAP * BBR) / (DX + GAP));
    return ix;
  }

  /**
   * Calculate iy from coordinate y
   * 
   * @param y
   * @return
   */
  private Integer getIY(Double y) {
    Integer iy = (int) ((y - STT_Y) / (DY + GAP));
    iy = (int) ((y - STT_Y - (iy / BBS) * GAP * BBR) / (DY + GAP));
    return iy;
  }

  /**
   * Calculate coordinate x from ix
   * 
   * @param ix
   * @return
   */
  private Double getGX(Integer ix) {
    return (double) (ix * (DX + GAP) + (ix / BBS) * GAP * BBR + STT_X + DX / 4);
  }

  /**
   * Calculate coordinate y from iy
   * 
   * @param iy
   * @return
   */
  private Double getGY(Integer iy) {
    return (double) (iy * (DY + GAP) + (iy / BBS) * GAP * BBR + STT_Y + 5 * DY / 6);
  }
  
  /**
   * set a candidate number to candidates
   * @param gx
   * @param gy
   */
  private void clickCell(Double gx, Double gy) {
    Integer ix = getIX(gx);
    Integer iy = getIY(gy);
    CellFx cell = cellXs[iy][ix];
//  if (cell.getVal() != null && cell.getOrgFlag()) {
    if (cell.getVal() != null) {
      int val = cell.getVal();
      log.println("clicked a number : " + val);
      clickNumber(ix, iy, val);
    } else {
      clrCellColor();
      if (!cell.getOrgFlag()) {
        cell.setCommFlag(true);
      }
    }
  }
  
  /**
   * 
   * @param val
   */
  private void clickNumber(int xp, int yp, int val) {
    clrCellColor();
    
    // color a cell box
    for (int p[] : Utils.getBoxCoord(xp, yp)) {
      int y = p[0];
      int x = p[1];
      cellXs[y][x].getRect().setFill(RECT_MARKED_COLOR);
    }
    
    // color a cell line
    for (int p[] : Utils.getLineCood(xp, yp)) {
      int y = p[0];
      int x = p[1];
      cellXs[y][x].getRect().setFill(RECT_MARKED_COLOR);
    }

    // color a cell row
    for (int p[] : Utils.getRowCood(xp, yp)) {
      int y = p[0];
      int x = p[1];
      cellXs[y][x].getRect().setFill(RECT_MARKED_COLOR);
    }

    // color the specified number cells
    for (int p[] : Utils.getAllCoord()) {
      int y = p[0];
      int x = p[1];
      CellFx cell = cellXs[y][x];
      if (cell.getVal() != null && val == cell.getVal()) {
        cell.getRect().setFill(RECT_CLICK_COLOR);
      }
    }
  }
  
  /**
   * Clear Cell Color
   */
  private void clrCellColor() {
    for (int p[] : Utils.getAllCoord()) {
      setCellColor(cellXs[p[0]][p[1]], RECT_NORMAL_COLOR);
    }
  }
  
  /**
   * Set the Cell Color
   */
  private void setCellColor(CellFx cell, Color color) {
    cell.getRect().setFill(color);
  }

  /**
   * set a candidate number to candidates
   * @param gx
   * @param gy
   */
  private void setCandidates(Double gx, Double gy) {
    Integer ix = getIX(gx);
    Integer iy = getIY(gy);
    CellFx cell = cellXs[iy][ix];
    // current value
    if (cell.getVal() == null || cell.getOrgFlag()) {
      return;
    }
    int val = cell.getVal();
    // string candidates
    String strCand = cell.getStrCand();
    strCand = (strCand == null || "".equals(strCand)) ? EMP_CANDIDATES : strCand;
    String strCandUpd = "";
    for (int n : nlist) {
      if (" ".equals(strCand.substring(n - 1, n)) && val == n) {
        strCandUpd = strCandUpd + n;
      } else if (!" ".equals(strCand.substring(n - 1, n))  && val == n) {
        strCandUpd = strCandUpd + " ";
      } else if (!" ".equals(strCand.substring(n - 1, n))  && val != n) {
        strCandUpd = strCandUpd + n;
      } else {
        strCandUpd = strCandUpd + " ";
      }
    }
    cell.setStrCand(strCandUpd);
    cell.setCand(setupCand(strCandUpd));
    // log.println("cell val=" + cell.getVal());
    cell.setVal(null);
  }
  
  /**
   * setup String candidates to Text Candidates
   * @param s
   * @return
   */
  private String setupCand(String s) {
    String co = "";
    for (int n : nlist) {
      if (s.length() >= n) {
        co = co +  s.substring(n - 1, n) + " ";
      }
      if (n == 3 || n == 6) {
        co = co + "\n";
      }
    }
    return co;
  }
}
