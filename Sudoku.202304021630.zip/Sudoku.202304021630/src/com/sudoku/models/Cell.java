package com.sudoku.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Cell Class - Sudoku Board Cell
 *
 * @author npm091
 *
 */
public class Cell extends Point {
  /** cell value for solver (bit value) */
  private int val;

  /** cell status */
  @Getter
  @Setter
  private CellStatus status;

  /**
   * Constructor
   *
   * @param x
   * @param y
   * @param val
   */
  public Cell(Point p, int val) {
    this.x = p.x;
    this.y = p.y;
    initCell(val);
  }

  /**
   * Constructor
   *
   * @param x
   * @param y
   * @param val
   * @param cand
   */
  public Cell(Point p, int val, int cand) {
    this.x = p.x;
    this.y = p.y;
    initCell(val);
    this.cand = cand;
  }

  /**
   * initialize Cell val and candidate
   *
   * @param val
   */
  private void initCell(int val) {
    this.cand = (val == 0) ? Constants.ALL_CAND_BITS : 0;
    this.status = CellStatus.INIT;
    setVal(val);
  }

  /**
   * Delete the cell value
   *
   * @return result
   */
  public boolean delete() {
    if (this.val != 0 && this.status == CellStatus.INIT) {
      this.status = CellStatus.DELETED;
      this.val = 0;
      this.cand = Constants.ALL_CAND_BITS;
      return true;
    }
    return false;
  }

  /**
   * Restore the cell value
   *
   * @return result
   */
  public void restore() {
    // this.val = this.oval;
    this.status = CellStatus.REQUIRED;
  }

  /**
   * Clear the candidate bit for the val
   *
   * @param val
   */
  public boolean clrCand(int val) {
    int tb = 1 << (val - 1);
    boolean ret = (this.cand & tb) != 0;
    this.cand &= ~tb;
    return ret;
  }

  /**
   * Check if the val can be placed to the cell
   *
   * @param val
   */
  public boolean canPlace(int val) {
    int tb = 1 << (val - 1);
    return (this.cand & tb) != 0;
  }

  /**
   * getter for val as decimal
   */
  public int getVal() {
    return (this.val == 0) ? 0 : Utility.getNtz(this.val);
  }

  /**
   * getter for val as bit
   */
  public int getBitVal() {
    return this.val;
  }

  /**
   * setter for val as bit
   *
   * @param val
   */
  public void setVal(int val) {
    this.val = (val == 0) ? 0 : 1 << (val - 1);
    // this.oval = (val == 0) ? 0 : 1 << (val - 1);
  }

  /**
   * getter for val as decimal
   *
   * @param plen
   */
  public String getCandStr(int plen) {
    String ret = "";

    int candLen = Utility.countBits(cand);
    int n = 0;
    for (int i = 1, b = 1; i <= 9; i++) {
      if ((cand & b) != 0) {
        n++;
        if (plen > n) {
          ret += String.format("%1d", i);
        } else {
          ret += ((plen <= n) && (candLen > n)) ? String.format("%1d", i) : ".";
        }
        if (plen <= n) {
          break;
        }
      }
      b = b << 1;
    }
    ret = ret + "        ";
    return ret.substring(0, plen);
  }

  /**
   * Object clone
   *
   */
  @Override
  public Cell clone() {
    Cell tcell = new Cell(this, this.getVal());

    return tcell;
  }
}
