package model;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import lombok.Getter;
import lombok.Setter;
import misc.Constant;

/**
 * Sudoku Cell Class
 * 
 * @author npm091
 * 
 * @since 2022/Mar/10th
 * @version 1.0 - 2022/Mar/12th
 */
public class CellFx extends Constant {
  // -----------------------------------------------------------------------
  // Variables
  // -----------------------------------------------------------------------
  /**
   * Cell Position X
   */
  @Setter
  @Getter
  private Integer x;

  /**
   * Cell Position Y
   */
  @Setter
  @Getter
  private Integer y;

  /**
   * Cell Text of Number
   */
  @Setter
  @Getter
  private Text txtNum;

  /**
   * Cell Text of Candidates
   */
  @Getter
  private Text txtCand;

  /**
   * String of txtCand 
   */
  @Setter
  @Getter
  private String strCand;
//
//  /**
//   * memo
//   */
//  @Setter
//  @Getter
//  private String memo;
  
  /**
   * Value Commit Flag
   */
  @Getter
  private Boolean commFlag;

  /**
   * Value Original Flag
   */
  @Getter
  private Boolean orgFlag;

  /**
   * Cell Value
   */
  @Getter
  private Integer val;

  /**
   * Answer Value
   */
  @Getter
  private Integer ans;

  /**
   * Rectangle
   */
  @Getter
  @Setter
  private Rectangle rect;
  
  /**
   * Computed Candidate Values
   */
  @Getter
  @Setter
  private List<Integer> compCandList = new ArrayList<Integer>();

  /**
   * Player Candidate Values
   */
  @Getter
  @Setter
  private List<Integer> playerCandList = new ArrayList<Integer>();

  // -----------------------------------------------------------------------
  // Methods
  // -----------------------------------------------------------------------
  /**
   * Constructor 1
   */
  public CellFx() {
    x = null;
    y = null;
    setVal(null);
    txtNum = null;
    commFlag = false;
    orgFlag = false;
  }

  /**
   * Constructor 2
   * 
   * @param x
   * @param y
   */
  public CellFx(Integer y, Integer x) {
    this.x = x;
    this.y = y;
    txtNum = new Text("");
    setVal(null);
    commFlag = false;
    orgFlag = false;
  }

  /**
   * Constructor 3
   * 
   * @param x
   * @param y
   * @param gx
   * @param gy
   */
  public CellFx(Integer y, Integer x, Double gy, Double gx) {
    this.x = x;
    this.y = y;
    txtNum = new Text("");
    txtNum.setX(gx);
    txtNum.setY(gy);
    txtCand = new Text("");
    txtCand.setX(gx - CELL_CAND_FONT_SIZE * 0.7);
    txtCand.setY(gy - CELL_CAND_FONT_SIZE * 2);
    setVal(null);
    commFlag = false;
    orgFlag = false;
  }

  /**
   * Clear original flag
   * 
   * @param flag
   */
  public void clearOrgFlag(Boolean flag) {
    if (flag) {
      txtNum.setFill(CELL_ORG_COLOR);
      txtNum.setStroke(CELL_STROKE_COLOR);
      commFlag = flag;
      orgFlag = flag;
    }
  }

  /**
   * Set commFlag
   * 
   * @param flag
   */
  public void setCommFlag(Boolean flag) {
    txtNum.setFill(flag ? CELL_COMMIT_COLOR : CELL_TEMP_COLOR);
    txtNum.setStroke(CELL_STROKE_COLOR);
    commFlag = flag;
  }

  /**
   * Set original Flag
   * 
   * @param flag
   */
  public void setOrgFlag(Boolean flag) {
    if (flag) {
      txtNum.setFill(CELL_ORG_COLOR);
      txtNum.setStroke(CELL_STROKE_COLOR);
      commFlag = flag;
      orgFlag = flag;
    }
  }

  /**
   * Set Cell Value
   * @param val
   */
  public void setVal(Integer val) {
    this.val = val;
    if (val != null) {
      txtNum.setFont(Font.font(CELL_NUM_FONT, CELL_NUM_FONT_SIZE));
      txtNum.setText(String.valueOf(val));
    } else {
      txtNum.setText("");
    }
  }

  /**
   * Set Candidate String
   * @param val
   */
  public void setCand(String s) {
    if (s != null && !"".equals(s)) {
      txtCand.setFont(Font.font(CELL_CAND_FONT, CELL_CAND_FONT_SIZE));
      txtCand.setFill(CELL_CAND_COLOR);
      txtCand.setText(String.valueOf(s));
    } else {
      txtCand.setText("");
    }
  }

  /**
   * Clear cell
   * 
   * @param flag
   */
  public void clear() {
    setVal(null);
    txtNum.setText("");
    txtCand.setText("");
    strCand = "";
    //memo = "";
    commFlag = false;
    orgFlag = false;
  }

  /**
   * Increment Cell Value
   * 
   * @param maxVal
   * @return val
   */
  public Integer incrementVal(Integer maxVal) {
    val = (val == null) ? 0 : val;
    val = (val < maxVal) ? (val + 1) : val;
    setVal(val);
    return val;
  }

  /**
   * Decrement Cell Value
   * 
   * @return val
   */
  public Integer decrementVal() {
    val = (val == null) ? 1 : val;
    val = (val > 1) ? (val - 1) : val;
    setVal(val);
    return val;
  }
}
