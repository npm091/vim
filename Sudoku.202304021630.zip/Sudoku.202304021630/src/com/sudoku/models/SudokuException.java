package com.sudoku.models;

@SuppressWarnings("serial")
/**
 * Sudoku Exception Super Class
 *
 * @author npm091
 */
class SudokuException extends Exception {
  SudokuException(String emsg) {
    super(emsg);
  }
}
