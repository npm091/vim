package com.sudoku.models;

/**
 * Constant values definition
 *
 * @author npm091
 *
 */
public class Constants {
  /** All candidate bits */
  public static final int ALL_CAND_BITS = 0x1ff;

  /** Solver recursive max */
  public static final int MAX_SOLVER = 7;

  /** Cell delete max number with creator */
  public static final int MAX_DELETE_NUM = ((9 * 9) - 10);

  /** Solver backtrack recursive call max depth number */
  public static final int MAX_DEPTH = (91 - 15);

  /** Delete cell count maximum */
  public static final int DEL_COUNT_MAX = (9 * 9);

}
