package com.sudoku.contollers;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.sudoku.models.Board;
import com.sudoku.models.Logger;
import com.sudoku.models.Utility;

/**
 * Sudoku File read and write answer
 *
 * @author npm091
 *
 */
public class Filer {
  /** Logger instance */
  private static Logger log = Logger.getLogger();

  /** Sudoku data directory name */
  private String dirName;

  /** Sudoku data file name */
  private String fileName;

  /** Sudoku data directory name */
  private static int questionNo = 0;

  /** Sudoku board data list */
  private List<StringBuilder> boardList = new ArrayList<StringBuilder>();

  /** Sudoku data file type (data type) */
  public static final String dataType = ".dat";

  /** Sudoku data file type (sudoku type) */
  public static final String sdkType = ".sdk";

  /**
   * Constructor - No read Sudoku data file
   *
   */
  public Filer() {
    init("./data", null);
  }

  /**
   * Constructor
   *
   * @param dirName  - Directory name storing game and answer file
   * @param fileName - Game file name
   */
  public Filer(String dirName, String fileName) {
    init(dirName, fileName);
  }

  /**
   * initialize for Constructor
   *
   * @param dirName  - Directory name storing game and answer file
   * @param fileName - Game file name
   */
  private void init(String dirName, String fileName) {
    this.dirName = dirName;
    this.fileName = fileName;
    questionNo = 0;
    boardList = new ArrayList<StringBuilder>();
    if (null != fileName && fileName.contains(dataType)) {
      dataReader();
    } else if (null != fileName && fileName.contains(sdkType)) {
      sudokuReader();
    }
  }

  /**
   * Get game board with specifying number
   *
   * @param n - Game number
   * @return Game board object
   */
  public Board get(int n) {
    if ((n + 1) > size()) {
      return null;
    }

    Board bd = new Board();
    String bdStr = new String(boardList.get(n));
    for (int i = 0; i < 9; i++) {
      int vals[] = parseBoard(bdStr, i);
      bd.setCellsValLine(i, vals);
    }
    return bd;
  }

  /**
   * Write question board to file (Sudoku file type)
   *
   * @param creator    - Creator object
   * @param qbFile     - Question file name
   * @param headerFlag - Header flag
   */
  public void append(Board qboard, Board aboard, int level) {
    String pathname = dirName + "/" + fileName + sdkType;

    appendLine(pathname, "// Question#%d Level=%d @%s\n%s\n", ++questionNo, level, Utility.dateTimeStamp(),
        qboard.toSaveString());
    if (null != aboard) {
      appendLine(pathname, "// Answer\n%s\n", aboard.toSaveString());
    }
  }

  /**
   * Write answer to file
   *
   * @param solver - Solver object
   * @param level  - Game difficulty level
   */
  public void append(Solver solver, String resultFile, boolean levelFlag) {
    String pathname = null;
    String qstr = null;

    if (levelFlag) {
      int level = solver.getLevel();
      pathname = String.format("%s/" + resultFile, dirName, level);
      qstr = String.format("// Question#%d Level=%d @%s\n%s", ++questionNo, level, Utility.dateTimeStamp(),
          solver.board);
    } else {
      pathname = String.format("%s/" + resultFile, dirName);
      qstr = String.format("// Question#%d Level=? @%s\n%s", ++questionNo, Utility.dateTimeStamp(), solver.board);
    }

    appendLine(pathname, qstr);
    if (solver.ansBoard.size() == 1) {
      appendLine(pathname, "// Answer#%d\n%s", questionNo, solver.ansBoard.get(0));
    } else {
      appendLine(pathname, "// No Answer ... Wrong Game Board\n");
    }
  }

  /**
   * Append line to answer file
   *
   * @param pathname
   * @param line
   */
  private void appendLine(String pathname, String fmt, Object... args) {
    try {
      File file = new File(pathname);
      FileWriter filewriter = new FileWriter(file, true);
      filewriter.write(String.format(fmt, args));
      filewriter.close();

    } catch (Exception e) {
      log.error("SudokuFile.appendLine(): FIle(%s) access error", pathname);
    }
  }

  /**
   * Parse board lines
   *
   * @param lines
   * @param n
   * @return cells array
   */
  private int[] parseBoard(String lines, int n) {
    int[] iret = new int[9];
    String line;
    try {
      line = lines.substring(n * 9, (n + 1) * 9);
      int idx = 0;
      for (char s : line.toCharArray()) {
        if (s >= '1' && s <= '9') {
          iret[idx++] = s - '0';
        } else {
          iret[idx++] = 0;
        }
      }
      return iret;
    } catch (Exception e) {
      log.error("SudokuFile.parseBoard(): File(%s) parse error", fileName);
    }
    return null;
  }

  /**
   * Size of read board size
   *
   * @return
   */
  public int size() {
    return boardList.size();
  }

  /**
   * Sudoku file reader (data type)
   */
  public void dataReader() {
    FileReader fr = null;
    BufferedReader br = null;
    String pathname = dirName + "/" + fileName;

    try {
      fr = new FileReader(pathname);
      br = new BufferedReader(fr);

      String line = "";
      StringBuilder bd = new StringBuilder();
      for (int no = 0; null != line;) {
        for (int y = 0; y < 9;) {
          if (null == (line = br.readLine())) {
            break;
          }
          StringBuilder cells = getLineData(line);
          if (null == cells) {
            continue;
          }
          if (y == 0) {
            bd = new StringBuilder();
          }
          bd.append(cells);
          y++;
          if (y >= 9) {
            boardList.add(bd);
            no = no + 1;
          }
        }
      }
    } catch (FileNotFoundException e) {
      log.error("SudokuFile.reader(): %s is not found\n", pathname);
    } catch (IOException e) {
      log.error("SudokuFile.reader(): %s cannot be accessed\n", pathname);
    } catch (Exception e) {
      log.error("SudokuFile.reader(): unknow error\n");
    } finally {
      try {
        br.close();
        fr.close();
      } catch (Exception e) {
        log.error("SudokuFile.reader(): %s cannot be closed\n", pathname);
      }
    }
  }

  /**
   * Sudoku file reader (sudoku type)
   */
  public void sudokuReader() {
    FileReader fr = null;
    BufferedReader br = null;
    String pathname = dirName + "/" + fileName;

    try {
      fr = new FileReader(pathname);
      br = new BufferedReader(fr);

      String line = "";
      for (int no = 0; null != line;) {
        if (null == (line = br.readLine())) {
          break;
        }
        StringBuilder cells = getLineSdk(line);
        if (null != cells) {
          boardList.add(cells);
          no = no + 1;
        }
      }
    } catch (FileNotFoundException e) {
      log.error("SudokuFile.reader(): %s is not found\n", pathname);
    } catch (IOException e) {
      log.error("SudokuFile.reader(): %s cannot be accessed\n", pathname);
    } catch (Exception e) {
      log.error("SudokuFile.reader(): unknow error\n");
    } finally {
      try {
        br.close();
        fr.close();
      } catch (Exception e) {
        log.error("SudokuFile.reader(): %s cannot be closed\n", pathname);
      }
    }
  }

  /**
   * Read a line and set to the game board (Data type)
   *
   * @param line
   * @return
   */
  private static StringBuilder getLineData(String line) {
    StringBuilder sret = new StringBuilder();
    String fComment = "//";
    String fBody = "(\\s|\\-|[0-9]){3}[\\s\\|]+(\\s|\\-|[0-9]){3}";
    Pattern pComment = Pattern.compile(fComment);
    Pattern pBody = Pattern.compile(fBody);
    Matcher mComment = pComment.matcher(line);
    Matcher mfBody = pBody.matcher(line);

    if (!mComment.find() && mfBody.find()) {
      for (char s : line.toCharArray()) {
        if ((s == '-') || (s >= '1' && s <= '9')) {
          sret.append(s);
        }
      }
      return sret;
    }
    return null;
  }

  /**
   * Read a line and set to the game board (Sudoku type)
   *
   * @param line
   * @return
   */
  private static StringBuilder getLineSdk(String line) {
    StringBuilder sret = new StringBuilder();
    String fComment = "//";
    String fBody = "([0-9]){81}";
    Pattern pComment = Pattern.compile(fComment);
    Pattern pBody = Pattern.compile(fBody);
    Matcher mComment = pComment.matcher(line);
    Matcher mfBody = pBody.matcher(line);

    if (!mComment.find() && mfBody.find()) {
      sret.append(line);
      return sret;
    }
    return null;
  }
}
