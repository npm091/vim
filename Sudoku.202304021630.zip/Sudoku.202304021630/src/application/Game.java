package application;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

import com.sudoku.contollers.Creator;
import com.sudoku.models.Board;
import com.sudoku.models.Logger;
import com.sudoku.models.MultipleAswersException;
import com.sudoku.models.Point;
import com.sudoku.models.SolveResult;
import com.sudoku.models.SolverMode;
import com.sudoku.models.Utility;

import lombok.Getter;

/**
 * Game class - Create new sudoku game
 *
 * @author npm091
 * 
 * @version 1.0 - 2021/Jan/3rd  - initial
 * @version 1.1 - 2022/Mar/12th - append analyzer
 *
 */
public class Game {
  //------------------------------------------------------------------------------
  //- Constants and Variables
  //------------------------------------------------------------------------------
  /** Logger Class Instance */
  private static Logger log = Logger.getLogger();

  /** Sudoku question board */
  public Board qboard;

  /** Sudoku answer board */
  public Board aboard;

  /** Sudoku answer board */
  public List<Board> ansBoard = new ArrayList<Board>();;

  /** Sudoku game level */
  @Getter
  private int level = 0;

  /** Backtrack read ahead depth loop count */
  private int depthLoop = 0;

  /** Backtrack read ahead depth */
  @Getter
  private int depth = 0;

  /** Maximum read ahead depth with backtrack */
  public int depth_max = 0;

  /** Read ahead depth at getting answer */
  public int depth_result = 0;

  /** Board stack for  */
  public Deque<Board> stack = new ArrayDeque<Board>();

  /** Flag if set check consistency of given board */
  private boolean checkConsistency = true;

  public List<Point> ps = null;
  
  public List<Point> ps1 = null;
  public List<Point> ps2 = null;

  /**
   * Constructor
   */
  public Game() {
    depth = 0;
    depth_max = 0;
    depth_result = 0;
    this.checkConsistency = false;
    Logger.setLevel(Logger.LEVEL_NOTICE);
    Creator creator = new Creator(true, SolverMode.JUDGE_LEVEL);
    creator.create(8);
    qboard = creator.getQboard();
    aboard = creator.getAboard();
    log.notice("%s\n", qboard);
    log.debug("%s\n", aboard);
  }

  /**
   * Sudoku analyzer
   * 
   * @param pboard - Sudoku Board
   * @param loop - Loop counter for analyzer depth
   * @param rcFlag - Recursive Call Flag
   * @return List of Point
   */
  public List<Point> analyzer(Board pboard, int loop, int depthFlag) {
    level = 0;
    depth = 0;
    depth_max = 0;
    depth_result = 0;
    ansBoard = new ArrayList<Board>();
    finder(pboard, loop, depthFlag);
    return ps;
  }

  /**
   * Find the Sudoku Game 
   * 
   * @param pboard
   * @param loop
   * @param pDepth
   */
  private void finder(Board pboard, int loop, int pDepth) {
    Board lboard = new Board(pboard);

    ps = lboard.sieveCells(true, SolverMode.FAST_MODE);
    ps1 = ps;
    level = (level < 1) ? lboard.getLevel() : level;
    log.info("Solver.finder()\n");

    // Return if found answer
    if (ps.size() == 0 && SolveResult.COMPLETED == Utility.isCompleted(lboard)) {
      log.info("Solver.finder(): level:%d\n", level);
      ansBoard.add(lboard.clone());
      return;
    }

    // Search answer by back track method
    depth = 0;
    depthLoop = pDepth;
    depth_result = 0;
    depth_max = 0;
    try {
      backtrack(lboard, ps);
      level = 4 + (depth_result + 1) / 2;
      qboard = lboard;
      log.info("Solver.finder(): level:%d(%d)\n", level, ansBoard.size());
    } catch (MultipleAswersException e) {
      level = 0;
      log.info("Solver.finder(): %s\n", e);
    }
  }

  /**
   * Back Track Method for Analyzer - Call recursively with backtrackPlace method
   *
   * @param pboard
   * @param ps
   * @return result
   * @throws MultipleAswersException
   */
  private SolveResult backtrack(Board pboard, List<Point> ps)
      throws MultipleAswersException {
    if (depth++ >= depthLoop || null == ps || ps.size() == 0) {
      depth--;
      return SolveResult.FAILED;
    }

    SolveResult result = SolveResult.IN_PROGRESS;
    // int n = 0;
    for (Point p : ps) {
      List<Integer> cands = Utility.candList(pboard.getCells()[p.y][p.x]);
      if (cands.size() > 0) {
        result = backtrackPlace(pboard, p, cands);
        if (checkConsistency != true && SolveResult.COMPLETED == result) {
          break;
        }
        if (SolveResult.FAILED == result) {
          break;
        }
      }
    }
    depth_max = (depth_max < depth) ? depth : depth_max;
    depth--;
    return result;
  }

  /**
   * backtrackPlace - Placing tentative answer and check consistency,
   *                  Call recursively with backtrackPlace method
   *
   * @param lboard - Game board to solve
   * @param p - Point list where can be placed value
   * @param cands - candidate value list
   * @return Solving result
   * @throws MultipleAswersException - Exception when find out multiple answers
   */
  private SolveResult backtrackPlace(Board lboard, Point p, List<Integer> cands)
      throws MultipleAswersException {
    SolveResult result = SolveResult.IN_PROGRESS;

    // Try placing all the candidate answers
    for (Integer val : cands) {
      stack.push(lboard.clone());
      boolean res = lboard.placeVal(p, val);
      if (!res) {
        log.debug("Solver.backtrackPlace(): Contradiction, maybe system error\n");
        lboard = stack.pop();
        continue;
      }

      Board tboard = lboard.clone();
      List<Point> tps = tboard.sieveCells(true, SolverMode.FAST_MODE);
      result = Utility.isConsistency(tboard);
      log.debug("%sp%s.setv(%d)->result=%s\n", Utility.strRepeat("_", depth), p, val, result);
      if (SolveResult.IN_PROGRESS == result) {
        Utility.copyBoard(lboard, tboard);
        log.debug("Solver.backtrackPlace(): solving in progress\n");
        if (SolveResult.COMPLETED == Utility.isCompleted(lboard)) {
          // Check if the answer board is already registered
          depth_result = (depth_result < depth) ? depth : depth_result;
          if (Utility.isStored(ansBoard, lboard) < 0) {
            ansBoard.add(lboard.clone());
            if (ansBoard.size() > 1) {
              log.debug("Solver.backtrackPlace(): error wrong game\n");
              throw new MultipleAswersException();
            }
          }
          // When answer found, return immediately if checker flag is NOT set
          if (checkConsistency != true) {
            // try it!
            ps2 = tps;
            lboard = stack.pop();
            return SolveResult.COMPLETED;
          }
        }
        if (null != tps && tps.size() > 0) {
          result = backtrack(lboard, tps);
          // When answer found, return immediately if checker flag is NOT set
          if (checkConsistency != true && result == SolveResult.COMPLETED) {
            // try it!
            ps2 = tps;
            lboard = stack.pop();
            return SolveResult.COMPLETED;
          }
        }
        // Restore board
        lboard = stack.pop();
        continue;
      }
      // Restore board
      lboard = stack.pop();
    }
    return result;
  }
}
