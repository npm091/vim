package com.sudoku.models;

@SuppressWarnings("serial")
/**
 * Multiple Answers Exception
 *
 * @author npm091
 */
public class MultipleAswersException extends SudokuException {
  public MultipleAswersException() {
    super("foud multipe answers");
  }
}
