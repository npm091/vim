package com.sudoku.models;

import lombok.Getter;
import lombok.Setter;

/**
 * Tiny log
 *
 * @author npm091
 *
 */
public class Logger {
  /** singleton instance */
  private static Logger singleton = new Logger();

  /** Log levels definition */
  public static final int LEVEL_ERROR = 0;
  public static final int LEVEL_NOTICE = 1;
  public static final int LEVEL_INFO = 2;
  public static final int LEVEL_DEBUG = 3;

  /** Log level */
  @Getter
  @Setter
  public static int level = LEVEL_ERROR;

  /**
   * constructor - because singleton nothing to do
   */
  private Logger() {
  }

  /**
   * Get instance
   *
   * @return
   */
  public static Logger getLogger() {
    return singleton;
  }

  /**
   * debug logging
   *
   * @return
   */
  public void debug(String fmt, Object... args) {
    if (level >= LEVEL_DEBUG) {
      System.out.printf(fmt, args);
    }
  }

  /**
   * info logging
   *
   * @return
   */
  public void info(String fmt, Object... args) {
    if (level >= LEVEL_INFO) {
      System.out.printf(fmt, args);
    }
  }

  /**
   * notice logging
   *
   * @return
   */
  public void notice(String fmt, Object... args) {
    if (level >= LEVEL_NOTICE) {
      System.out.printf(fmt, args);
    }
  }

  /**
   * error logging
   *
   * @return
   */
  public void error(String fmt, Object... args) {
    if (level >= LEVEL_ERROR) {
      System.out.printf(fmt, args);
    }
  }

  /**
   * print logging
   *
   * @return
   */
  public void print(String fmt, Object... args) {
    System.out.printf(fmt, args);
  }

  /**
   * print logging
   *
   * @return
   */
  public void println(String fmt, Object... args) {
    System.out.printf(fmt, args);
    System.out.println();
  }

}
